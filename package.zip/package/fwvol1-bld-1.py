import netCDF4 as nc4
from ferr import use
import numpy as np

j1 = 44
i1 = 226

dso1 = nc4.MFDataset('so/so_ann*.nc')

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]


darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[:85]
area1 = area[:85]
area1m = area1*ao_msk1

so1 = dso1.variables['so'][:,:,:85]
so1m = so1*ao_msk1.reshape(1,1,85,256)

dvol = use('volcello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
vol = dvol.v['volcello'][:,:85]
fwf1 = (35.0 - so1m) / 35.

# vol.count()
# fwf1.count()

fwvol1 = fwf1*vol.reshape(1,40,85,256)

fwtot1 = fwvol1.sum(axis=3).sum(axis=2).sum(axis=1)

fwarccm1 = fwtot1 / area1m.sum()

fw1 = np.array(fwarccm1)
np.save('fwtot_forced.npy',fw1)

fwvol1_da = fwvol1.sum(axis=1)
fwht1 = fwvol1_da / area1m.reshape(1,85,256)
np.save('fwht_forced.npy',fwht1.data)
