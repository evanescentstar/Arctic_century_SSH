import mcmath
import mcp
import numpy as np
import scipy as sp
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import cm

# if 'psl_111' not in globals().keys():
execfile('load-point-correl-data-1.py')

from mcmath import tyx2tm_arr, tm2tyx_arr

def pt_corrmap2(pt1, x):
    """Input array 'x', with dims ('t,y,x'), is correlated with a single time series 'pt1' at all valid spatial locations.
    Requires (at present) that the input array doss not have any missing values in the time series;
    it can have missing values for an entire spatial location (i.e., no time values there at all). """

    newarr, loc1 = tyx2tm_arr(x)
    outarr = np.zeros(newarr.shape[1])
    for i in xrange(len(outarr)):
        outarr[i] = np.corrcoef(pt1, newarr[:, i])[1, 0]

    out1 = tm2tyx_arr(outarr, loc1, x.shape[1:])

    return out1


yl = 16

arcind = 48
pslarc = psl[:, arcind:]
x1 = psl.x
y1 = psl.y[-yl:]
y0 = psl.y[arcind:]

psl_dt0 = mcmath.my_dtrnd(psl[:, arcind:], np.arange(1000.), 0) / 100.
psl_111dt0 = mcmath.rm_calc(psl_dt0, 'h', 111, 1)[1]
psl_mean0 = psl_111dt0.mean(axis=0)
psl_1110 = psl_111dt0 - psl_mean0.reshape(1, arcind, 192)
psl111mn0 = mcmath.area_cswt_mean(psl_1110, y0)
psl111trnd0 = mcmath.trnd_calc(np.arange(890.), psl111mn0)
p111tline0 = np.arange(890.) * psl111trnd0[0]
psl_111_dt0 = psl_1110 - p111tline0.reshape(890, 1, 1)

icef_sum111_trnd = mcmath.trnd_calc(np.arange(890.), icef_sum111)
i111tline = np.arange(890.) * icef_sum111_trnd[0]
ice111_dt = icef_sum111 - i111tline

########################## PLOTTING
fig = plt.figure(figsize=(6.7,8))

# subplot placements
rect_ll = 0.025, 0.08, 0.470,0.26
rect_lr = 0.515, 0.08, 0.470,0.26
rect_ml = 0.025, 0.39, 0.470,0.26
rect_mr = 0.515, 0.39, 0.470,0.26
rect_ul = 0.025, 0.70, 0.470,0.26
rect_ur = 0.515, 0.70, 0.470,0.26

ex=0.025
xe=0.015
sx=0.015

# text placements
titl_plc = (0.02,1.03)
rtxt_plc = (0.00,0.98)
lett_plc = (-0.08,1.02)

## panel titles

t1a = 'SLP pattern :: WFO ts'
t1b = 'CTL-P SLP :: WFO'
t1c = 'SAT pattern :: WFO ts'
t1d = 'CTL-P SAT :: WFO'
t1e = 'SAT pattern :: ice transport ts'
t1f = 'CTL-P SAT :: ice transport'

cmapuse = cm.RdBu_r
blat1 = 5

################ A
ax = fig.add_axes(rect_ul)

wfots111 = mcmath.run_mean_win_mskd(wfodt, sp.signal.boxcar(111))[1]

cormap_psl_wfo = pt_corrmap2(wfots111, psl_111_dt0)
mcp.shade(x1, y0, cormap_psl_wfo, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1a, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'a.)', ha='left', va='bottom', size=10, transform=ax.transAxes)
##

################ C
ax = fig.add_axes(rect_ml)

tas111 = mcmath.rm_calc(tas, 'b', 111, 1)[1]
arctas111 = tas111[:, 48:]
arctas111dt = mcmath.my_dtrnd(arctas111, np.arange(890))

cormap_tas_wfo = pt_corrmap2(wfots111, arctas111)
mcp.shade(x1, y0, cormap_tas_wfo, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1c, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'c.)', ha='left', va='bottom', size=10, transform=ax.transAxes)
##


################ E
ax = fig.add_axes(rect_ll)

cormap_tas_ice = pt_corrmap2(ice111_dt, arctas111)

mcp.shade(x1, y0, cormap_tas_ice, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1e, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'e.)', ha='left', va='bottom', size=10, transform=ax.transAxes)

##
## delete forced run vars

del wfots111, wfodt
del psl_111_dt0, psl
del ice111_dt
del arctas111, tas

####### load control data

execfile('load-point-correl-data-3-ctlp.py')

yl = 16
tend = 1000
arcind = 48
pslarc = psl[:, arcind:]

psl_dt0 = mcmath.my_dtrnd(psl[:tend, arcind:], np.arange(1000.), 0) / 100.
psl_111dt0 = mcmath.rm_calc(psl_dt0, 'h', 111, 1)[1]
psl_mean0 = psl_111dt0.mean(axis=0)
psl_1110 = psl_111dt0 - psl_mean0.reshape(1, arcind, 192)
psl111mn0 = mcmath.area_cswt_mean(psl_1110, y0)
psl111trnd0 = mcmath.trnd_calc(np.arange(890.), psl111mn0)
p111tline0 = np.arange(890.) * psl111trnd0[0]
psl_111_dt0 = psl_1110 - p111tline0.reshape(890, 1, 1)

icef_sum111_trnd = mcmath.trnd_calc(np.arange(890.), icef_sum111[:tend-110])
i111tline = np.arange(890.) * icef_sum111_trnd[0]
ice111_dt = icef_sum111[:tend-110] - i111tline

################ B
ax = fig.add_axes(rect_ur)

wfots111 = mcmath.run_mean_win_mskd(wfodt[:tend], sp.signal.boxcar(111))[1]
cormap_psl_wfo = pt_corrmap2(wfots111, psl_111_dt0)

mcp.shade(x1, y0, cormap_psl_wfo, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1b, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'b.)', ha='left', va='bottom', size=10, transform=ax.transAxes)

###

################ D
ax = fig.add_axes(rect_mr)

tas = np.ma.MaskedArray(tas)
tas111 = mcmath.rm_calc(tas[:tend], 'b', 111, 1)[1]
arctas111 = tas111[:, 48:]
arctas111dt = mcmath.my_dtrnd(arctas111, np.arange(890))

wfots111 = mcmath.run_mean_win_mskd(wfodt[:tend], sp.signal.boxcar(111))[1]
cormap_psl_wfo = pt_corrmap2(wfots111, arctas111)

mcp.shade(x1, y0, cormap_psl_wfo, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1d, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'd.)', ha='left', va='bottom', size=10, transform=ax.transAxes)

###


################ F
ax = fig.add_axes(rect_lr)


cormap_tas_ice = pt_corrmap2(ice111_dt, arctas111)

mcp.shade(x1, y0, cormap_tas_ice, proj='npl', blat=blat1, lon0=315, vmin=-0.7, vmax=0.7, cmap=cm.RdBu_r, add=1,
          nocb=True)

plt.text(titl_plc[0], titl_plc[1], t1f, ha='left', size=10, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'f.)', ha='left', va='bottom', size=10, transform=ax.transAxes)

###

ax = fig.add_axes((0.2,0.04,0.6,0.02))
norm = mpl.colors.Normalize(vmin=-0.7,vmax=0.7)
cb2 = mpl.colorbar.ColorbarBase(ax, cmap=cm.RdBu_r,
                                     norm=norm,
                                     extend='both',
                                     #ticks=bnds3, # optional
                                     spacing='proportional',
                                     orientation='horizontal')

plt.savefig('fig8_atmos-pt-corr-cmp-3.png', dpi=300)
