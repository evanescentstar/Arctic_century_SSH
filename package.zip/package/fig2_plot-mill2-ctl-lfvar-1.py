import mcmath
import mcp
import netCDF4 as nc4
import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import cm

d1 = nc4.MFDataset('zos/zos_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')

zos = d1.variables['zos'][:]

lonv1 = d1.variables['lon_vertices'][:]
latv1 = d1.variables['lat_vertices'][:]

zos_dt = mcmath.my_dtrnd(zos, np.arange(1000.))
zos_lf = mcmath.rm_calc(zos_dt, 'h', 111, 1)[1]
zos_lf_std = zos_lf.std(axis=0, ddof=1)

###  millen 1 data proc

d2 = nc4.MFDataset('control/zos/zos_ann_*.nc')
dt2 = mcmath.n2d(d2.variables['time'][:], d2.variables['time'].units, d2.variables['time'].calendar)

zos2 = d2.variables['zos'][:]
zos2_dt = mcmath.my_dtrnd(zos2, np.arange(dt2.size))
zos2_lf = mcmath.rm_calc(zos2_dt, 'h', 111, 1)[1]
zos2_lf_std = zos2_lf.std(axis=0, ddof=1)

##### Plotting

fig = plt.figure(figsize=(3.5, 3.8))

# text placements
titl_plc = (0.5, 1.03)
rtxt_plc = (0.00, 0.98)
lett_plc = (0.0, 1.02)

# subplot placements
rect_t = 0.080, 0.553, 0.85, 0.40
rect_b = 0.080, 0.10, 0.85, 0.40

ex = 0.025
xe = 0.015
sx = 0.015

cmapuse = cm.nipy_spectral
v1 = 0.
v2 = 4.0

## titles

t1a = 'MPI-ESM-P past1000 run, std dev of 111-yr running means'
t1b = 'MPI-ESM-P piControl run, std dev of 111-yr running means'

#####  A
ax = fig.add_axes(rect_t)
m1, cs = mcp.cvshade(lonv1, latv1, zos_lf_std * 100, vlo=v1, vhi=v2, cmap=cmapuse, add=1, land1='darkgrey', nocb=True)
plt.sca(ax)
plt.text(titl_plc[0], titl_plc[1], t1a, ha='center', size=8, transform=ax.transAxes)

#####  B
ax = fig.add_axes(rect_b)
m1, cs = mcp.cvshade(lonv1, latv1, zos2_lf_std * 100, vlo=v1, vhi=v2, cmap=cmapuse, add=1, land1='darkgrey', nocb=True)
plt.text(titl_plc[0], titl_plc[1], t1b, ha='center', size=8, transform=ax.transAxes)

ax2 = fig.add_axes((0.1, 0.06, 0.8, 0.02))
norm = mpl.colors.Normalize(vmin=v1, vmax=v2)
cb2 = mpl.colorbar.ColorbarBase(ax2, cmap=cmapuse,
                                norm=norm,
                                extend='both',
                                ticks=[0., 2., 4., 6., 8.],  # optional
                                spacing='proportional',
                                orientation='horizontal')

plt.text(1.0, 0.5, '(cm)', ha='left', va='top', size=10, transform=ax2.transAxes)

plt.savefig('fig2_mill2-ctl-lfvar-1.png',dpi=300)
