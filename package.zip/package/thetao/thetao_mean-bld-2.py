from ferr import use
import netCDF4 as nc4
import numpy as np

scriptname = 'thetao_mean-bld-2.py'
fname = 'thetao_ann*.nc'

thetaomn = np.ma.zeros((40, 220, 256), dtype=np.float32)

dvol = use('../volcello_fx_MPI-ESM-P_past1000_r0i0p0.nc')

lat = dvol.gv('lat')
lon = dvol.gv('lon')
latv = np.transpose(dvol.gv('lat_vertices'), (2, 0, 1))
lonv = np.transpose(dvol.gv('lon_vertices'), (2, 0, 1))
lev = dvol.d['lev'][:]
lev_bnds = dvol.d['lev_bnds'][:]

j = 0

d1 = nc4.MFDataset(fname)

for i in xrange(40):
    thetao1 = d1.variables['thetao'][:, i]
    thetaomn[i] = thetao1.mean(axis=0)
    j = j + 1

d1.close()

nfname = 'thetao_mean.nc'

dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
dcur1.createDimension('j', lat.shape[0])
dcur1.createDimension('i', lat.shape[1])
dcur1.createDimension('lev', 40)
dcur1.createDimension('bnds', 2)
dcur1.createDimension('vertices', 4)

dcur1.history = 'created by script: %s' % scriptname
dcur1.processed_file = '%s' % fname

lat_var = dcur1.createVariable('lat', 'd', ('j', 'i'))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var.bounds = 'lat_vertices'
lat_var[:] = lat

lon_var = dcur1.createVariable('lon', 'd', ('j', 'i'))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var.bounds = 'lon_vertices'
lon_var[:] = lon

latbnd_var = dcur1.createVariable('lat_vertices', 'd', ('vertices', 'j', 'i'))
latbnd_var.units = 'degrees_north'
latbnd_var[:] = latv

lonbnd_var = dcur1.createVariable('lon_vertices', 'd', ('vertices', 'j', 'i'))
lonbnd_var.units = 'degrees_east'
lonbnd_var[:] = lonv

lev_var = dcur1.createVariable('lev', 'd', ('lev',))
lev_var.bounds = "lev_bnds"
lev_var.units = "m"
lev_var.axis = "Z"
lev_var.positive = "down"
lev_var.long_name = "ocean depth coordinate"
lev_var.standard_name = "depth"
lev_var[:] = lev

levbnds_var = dcur1.createVariable('lev_bnds', 'd', ('lev', 'bnds'))
levbnds_var[:] = lev_bnds

var1_var = dcur1.createVariable('thetao', 'f', ('lev', 'j', 'i'), fill_value=-1e34)
var1_var.long_name = "Potential temperature relative to surface"
var1_var.standard_name = "potential_temperature"
var1_var.units = "K"
var1_var.cell_methods = "time: mean"
var1_var.cell_measures = "area: areacello volume: volcello"
var1_var.coordinates = "lat lon"
var1_var.missing_value = np.float32(-1e34)

thetaomn.data[thetaomn.mask] = -1e34
var1_var[:] = thetaomn[:].copy()

dcur1.sync()
dcur1.close()
