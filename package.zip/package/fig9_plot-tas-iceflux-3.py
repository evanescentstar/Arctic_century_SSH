import mcmath
import mcp
import netCDF4 as nc4
from datetime import datetime as dt
import numpy as np
import scipy as sp
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import font_manager

prop1 = font_manager.FontProperties(size=9)

dflux1 = nc4.Dataset('fwflux_arc_5_svalbard.nc')
iceflux1 = dflux1.variables['iceflux'][:] * (30. / 35.)
tax = dflux1.variables['time'][:]

dflux2 = nc4.Dataset('fwflux_arc_5_canarc.nc')
iceflux2 = dflux2.variables['iceflux'][:] * (30. / 35.)

iceflux = np.r_[iceflux1, iceflux2] / 1000
icemask = np.r_[iceflux1.mask, iceflux2.mask]
iceflux.mask = icemask

iceflux2 = iceflux.sum(axis=2)
icefluxnew = np.ma.masked_all(iceflux2.shape)
icefluxnew[0] = iceflux2[24]
icefluxnew[1:5] = iceflux2[[23, 20, 22, 21]]
icefluxnew[5:] = iceflux2[:20]

icefluxdt = mcmath.my_dtrnd(icefluxnew.T, tax, True).T

icethk1 = np.load('icethk_1_canarc.npy')
icethk2 = np.load('icethk_1_svalbard.npy')
icethk = np.r_[icethk1, icethk2]
icethksum = icethk.sum(axis=0)
icethk111 = mcmath.run_mean_win_mskd(icethksum, sp.signal.boxcar(111))[1]
icethk111dt = mcmath.my_dtrnd(icethk111, tax[55:-55], 0)

icethkdt = mcmath.my_dtrnd(icethk.T, tax, True).T

icefluxdt_mn = icefluxdt.mean() / 1000.
ifdm_mn = icefluxdt_mn / icethkdt.mean()
iceflux_thk = ifdm_mn * icethkdt

ifdt_sum = icefluxdt.sum(axis=0) / 1000.
ifthk_sum = iceflux_thk.sum(axis=0)

ifdt_sum111 = mcmath.rm_calc(ifdt_sum, npts=111)[1]
ifthk_sum111 = mcmath.rm_calc(ifthk_sum, npts=111)[1]

itrans1 = ifdt_sum111
ithk1 = ifthk_sum111 - ifthk_sum111.mean() + ifdt_sum111.mean()

dt1dt = mpl.dates.num2date(tax)
yllen = 200
xlist = dt1dt[::100]

plt.figure()
mcp.dateplt_m(dt1dt[55:-55], itrans1, ticksize=10, yl=yllen, fmt='b-',
              label='Ice transport, from model variables transix, transiy')
mcp.dateplt_m(dt1dt[55:-55], ithk1, ticksize=10, yl=yllen, fmt='r-',
              label='Ice transport, average transport rate times ice concentration')
plt.legend(loc=4, prop=prop1)
plt.title('Ice transport time series comparison, mSv')

axa = plt.gca()
axa.set_xlim(dt(900, 1, 1), dt(1800, 1, 1))
axa.set_xticks(xlist[1:])
axa.set_ylim(-92, -78)

plt.savefig('fig9_ice-trans-cmp-3.png',dpi=200)
