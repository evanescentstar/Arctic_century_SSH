import mcmath
from ferr import use
import netCDF4 as nc4
import numpy as np

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[:85]
area1 = area[:85]
ao_area = ao_msk1 * area1

darea.f.close()

darea = use('areacella_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area_a = darea.gv('areacella')
lata = darea.d['lat'][:]
lona = darea.d['lon'][:]

arcind = 80
ao_area_a = area_a[arcind:]

d1 = nc4.MFDataset('control/tas/tas_ann_MPI-ESM-*.nc')
tax3 = d1.variables['time'][:]
tas = d1.variables['tas'][:]
tasy = d1.variables['lat'][:]
tast = d1.variables['time'][:]
arc_tas_mn = mcmath.area_cswt_mean(tas[:, -5:], tasy[-5:])

########################   PSL
dpsl = nc4.MFDataset('control/psl/psl_ann_MPI-ESM-*.nc')
psl = dpsl.variables['psl'][:]

#############   WFO
d1 = nc4.MFDataset('control/wfo/wfo_ann_MPI-ESM-*.nc')
t1 = d1.variables['time'][:]
dt1 = mcmath.n2d(t1)

wfo = d1.variables['wfo'][:, :85]
wfoarc = wfo * 0.001 * ao_area.reshape(1, 85, 256)
wfof = wfoarc.sum(axis=1).sum(axis=1)
wfodt = mcmath.my_dtrnd(wfof, t1)

dflux1 = nc4.Dataset('control/fwflux_arc_5_svalbard-P.nc')
fwflux1 = dflux1.variables['fwflux'][:]
iceflux1 = dflux1.variables['iceflux'][:] * (30. / 35.)

dflux2 = nc4.Dataset('control/fwflux_arc_5_canarc-P.nc')
fwflux2 = dflux2.variables['fwflux'][:]
iceflux2 = dflux2.variables['iceflux'][:] * (30. / 35.)

iceflux = np.r_[iceflux1, iceflux2[1:], iceflux2[0].reshape(1, tax3.size, 3)]
icemask = np.r_[iceflux1.mask, iceflux2[1:].mask, iceflux2[0].mask.reshape(1, tax3.size, 3)]
iceflux.mask = icemask
icef_sum = iceflux.sum(axis=2).sum(axis=0)
icef_std = icef_sum.std(axis=0, ddof=1)
icef_sum111 = mcmath.rm_calc(icef_sum, npts=111)[1]
