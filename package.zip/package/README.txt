README.txt

## INTRODUCTION ##

This package contains the scripts that the authors of Carson et al. 2022 (citation at the bottom) used to analyze data files from the MPI-ESM-P global climate model.  In this analysis, we explored the nature and causes of low-frequency variability of halosteric SSH and freshwater content in the Arctic in a past-1000 year CMIP5 experiment.  Details and results of this analysis can be found in the paper.

The person who directly carried out the principal data analysis steps (guided in large part by my colleagues as well!) is Mark Carson, that is, me.  This is a package that contains cleaned-up scripts for building the raw data files into the format used in the investigation, and scripts used to produce the figures shown in the paper.  

The directory structure is much the same as the one I used during data analysis. The important data (NetCDF) files that are necessary for carrying out the final steps of building the figures are listed in the directories by name, but are zero size. When you follow the data processing steps and run the scripts listed below, always in the same folder as the downloaded files unless explicitly stated otherwise, these zero-size files will be replaced by the full size processed files. This is to keep this package a reasonable size (ie., below 1 GB).

Also, in this way, you can examine our data analysis methods and choices in the scripts, as well as have access to the resultant processed data used to inform our results.  However, in order to build the freshwater transport datasets, a number of large file sets were needed to be processed, particularly: uo (eastward ocean component) and vo (northward ocean component).  The monthly data files for these variables total 100 GB a piece (until annual means are calculated at which point they may be deleted), which can take a while to download and process especially since it was done for the both the forced run and the control run, so 400 GB in total.  Also, the mean ocean temperature file for the control run is needed to calculate the control-run halosteric Arctic SSH, but ocean temperature (thetao) isn’t used for anything else.  To spare the need to download 500 GB of data, I’m including the freshwater flux files, and the control-run mean thetao file, although you can calculate these yourself if you prefer.  I’ve marked these files in the lists below with a section flag (§) to remind you that you don’t have to download these if you want to save some time or disk space.  Lastly, some other small NetCDF files are already included for convenience (basin, Arctic mask and grid definitions, include grid cell area and volume).

To reiterate, the files are put in specific directories, are processed with the script file located in the same directory, and then some further steps are carried out in the parent directories for the control and forced (past1000) runs.

Next is the list of prerequisites for running the scripts, then the data processing steps, and finally the figure generation steps. 
*** NOTE *** If you only want to see the data that goes into just a few figures, or to plot only a few figures, you can skip the Data Processing steps and read the Figure Generation section that follows those sections, which will include a list of only the data processing steps that are needed to produce the data for each figure individually.  This can save some steps, downloading and disk space.  Of course you don’t need to ever re-do processing steps. Once you do, say, step I.2, you don’t need to do it again for a different figure requiring it.  I also decided near the end of making this README that I’ll include the forced run mean thetao file in case someone only wants to compute data for Fig. 6 or fig. 7 that don’t include thermosteric data to avoid having to download the 100 GB of thermosteric monthly data just to calculate that mean (for use in calculating halosteric SSH).


## PREREQUISITES ##

+ Python 2.7 (I know it’s old, but it’s what I used)
+ Python dependencies
	- Numpy, Scipy, and Matplotlib
	- Basemap (nowadays can be installed using Anaconda, which is recommended if you don’t already have access to it, as compiling from source is a bit complicated)
	- NetCDF4 python library
	- Some personal libraries of my own: mcmath, mcplot, and ferr (included in this package)
+ (Recommended, but not strictly required): Ipython
+ Disk Space: If you build the whole data tree, after removing the monthly data files the final tree will take up about 97 GB.  If you save the monthly files for all downloads without deleting them until all data have been processed using the steps below, the space temporarily taken up can be as much as 1000 GB.  Deleting monthly files after the end of each step will yield a temporary maximum hard drive storage requirement of about 200 GB during each of the larger datasets’ steps.

Ipython is useful for exploring the data interactively, and I often verified the figure quality and layout visually and interactively (Matplotlib plots are interactive) before saving.

In all of the following, the ‘root’ folder is the root directory of this package.  For many of the first steps, you will need to run scripts in the subdirectories of this root folder.  The ‘$’symbol is just to represent the Windows or Linux command prompt.  One final comment: make sure you have set up your environment variables so you can run python from a command line and that the environment variable $PYTHONPATH exists and at least contains the ‘py’ folder from this package (so that those modules are accessible to python).  This python path part is very important.

For getting the data: there are a number of CMIP5 repositories on the web.  You can do a web search for CMIP5 repository and find these files in a repository often by just searching on the first part of the file name (the variable name, e.g., ‘zos’ or ‘transix’, etc.) and the model name ‘MPI-ESM-P’ (don’t use the quote marks themselves).  Be careful that in selecting files to download that they are indeed MPI-ESM-P model data files and not MPI-ESM-LR or MPI-ESM-MR.  All forced-run data have ‘past1000’ in the file name, and all control data have ‘piControl’ in their file names.  The DKRZ WDC climate data portal may be one of the easier websites for data acquisition, especially compared to any of the ESGF sites (I hate to include a URL, since it could change at any time, and I won’t edit this part of the doc to keep it up-to-date, but currently it’s wdc.climate.de/ui).  Registration is required, but free.


## PRELIMINARY DATA PROCESSING ##

§ - Optional to download if building the freshwater flux files yourself, and not using the included ones along with the included control and forced mean thetao files (see Introduction)

I. OCEAN FILES

1. Download zos_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  from a repository, and put into a ‘zos’ subfolder and process them.  Processing involves running the following command in that folder: 

	$ python annualize_tyx-1.py zos_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 

	This produces the zos_ann_MPI-ESM-P_past1000_*.nc files in the zos folder. 

2. Download zos_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/zos’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py zos_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 

	(To save disk space, you can delete the *_Omon_* files after processing into  *_ann_* files.) 

3. Download wfo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘wfo’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py wfo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 

4. Download wfo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/wfo’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py wfo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 

§ 5. Download thetao_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  from a repository, and put into a ‘thetao’ subfolder and process them.  Processing involves running the following command in that folder (note that this annualize script is 4-d, tzyx and not just tyx, also for the next 7 entries).  Also, you don’t need this unless you want the data used for Figs. 4 and 5: 

	$ python annualize_tzyx-1.py thetao_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 

	(To save disk space, you should delete the *_Omon_* files after processing into  *_ann_* files.) 


§ 6. Download thetao_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/thetao’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py thetao_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 


7. Download so_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘so’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py so_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 


8. Download so_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/so’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py so_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 

§ 9. Download uo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  from a repository, and put into a ‘uo’ subfolder and process them.  Processing involves running the following command in that folder: 

	$ python annualize_tzyx-1.py uo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 


§ 10. Download uo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/uo’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py uo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 


§ 11. Download vo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘vo’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py vo_Omon_MPI-ESM-P_past1000_r1i1p1_*.nc 


§ 12. Download vo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/vo’ subfolder and process by running in that folder: 

	$ python annualize_tzyx-1.py vo_Omon_MPI-ESM-P_piControl_r1i1p1_*.nc 



II. OCEAN ICE FILES

13. Download sic_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/ice’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py sic_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc 

14. Download sic_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into an ‘ice’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py sic_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc 

15. Download sim_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into an ‘ice’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py sim_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc 


16. Download transix_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/ice/transi’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py transix_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc 

17. Download transiy_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/ice/transi’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py transiy_OImon_MPI-ESM-P_piControl_r1i1p1_*.nc 

18. Download transix_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘transi’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py transix_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc 

19. Download transiy_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘transi’ subfolder and process by running in that folder: 

	$ python annualize_tyx-1.py transiy_OImon_MPI-ESM-P_past1000_r1i1p1_*.nc 



III. ATMOSPHERE FILES

Note: It is important to save yourself unnecessary download times, as well as disk space, by only downloading the MONTHLY atmos files.  Unlike for the most of the ocean files, there are daily and sometimes 6-hourly atmos files.  Also, the scripts are only designed to average monthly data into annual data.  Make sure you see ‘mon’ and ‘Amon’ in the file lists and file names that you download.

20.  Download pr_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘pr’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  pr_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc

21.  Download pr_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/pr’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  pr_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc

22.  Download psl_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘psl’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  psl_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc

23.  Download psl_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/psl’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  psl_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc


24.  Download tas_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc  and put into a ‘tas’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  tas_Amon_MPI-ESM-P_past1000_r1i1p1_*.nc

25.  Download tas_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc  and put into a ‘control/tas’ subfolder, and process by running in that folder:

	$ python atmos-annualize_tyx-1.py  tas_Amon_MPI-ESM-P_piControl_r1i1p1_*.nc


## SECOND STAGE DATA PROCESSING ##


IV. BUILD THERMOSTERIC FILES

IV.a
First, build the mean temperature and mean salinity files from the annual means, from inside their respective directories.

From root/so:
$ python somean-bld-2.py

(You don’t need to do the following step unless you want to compute it yourself.)
From root/thetao:
$ python thetao_mean-bld-2.py

IV.b (only needed for Fig. 5)
Then, from the root folder, run:

$ python tsteric-bld-1.py

And finally,

$ python tster-zavg-1.py


V. BUILD HALOSTERIC FILES

V.a
From the root folder, run:

$ python hsteric-bld-3.py

And then:

$ python hster-zavg-3.py


V.b
For freshwater to halosteric comparisons in Fig. 4, run the following two scripts to calculate mean freshwater Arctic averages and the freshwater Arctic 2-d field both in terms of freshwater anomalous height:

$ python fwvol1-bld-1.py

$ python fwvol2-bld-1.py


VI. BUILD FRESHWATER FLUX FILES


$ python arc-flux-calc-5_total_svalbard.py

$ python arc-flux-calc-5_canarc.py



VII. BUILD ICE THICKNESS FILES


$ python arc-icethick-flux-1_svalbard.py

$ python arc-icethick-flux-1_canarc.py



VIII. BUILD CONTROL-RUN HALOSTERIC FILES

First, build the mean temperature and mean salinity files from the annual means, from inside their respective directories.

From /root/control/so:
$ python ctl-somean-bld-2.py


Then, from the root/control folder, run:

$ python ctl-hsteric-bld-1.py

And then:

$ python ctl-hster-zavg-1.py


IX. BUILD CONTROL-RUN FRESHWATER FLUX FILES


$ python ctlP-arc-flux-calc-5_total_svalbard.py

$ python ctlP-arc-flux-calc-5_canarc.py




#########################################
#########################################
## FIGURE GENERATION ##
#########################################
#########################################

Fig. 1:  No need to do the following, but you would download the Supplement for the online document ‘Climate forcing reconstructions for use in PMIP simulations of the last millennium’, found here (last accessed successfully on 21-Apr-2022):  https://gmd.copernicus.org/articles/4/33/2011/ 
Then, install the contents into a directory named ‘volc’ created in the root directory of this project.  This file is already present in this package.

Run: $ python fig1_volc_pr_corr-2.py
or inside Ipython: execfile(‘fig1_volc_pr_corr-2.py’)

##

Fig. 2:  Minimal data processing: I.1 and I.2.

Run: $ python fig2_plot-mill2-ctl-lfvar-1.py
or inside Ipython: execfile(‘fig2_plot-mill2-ctl-lfvar-1.py’)

##

Fig. 3:  Minimal data processing: I.1 and I.2.

Run: $ python fig3_ssh-eof-ctlcmp-4a.py
or inside Ipython: execfile(‘fig3_ssh-eof-ctlcmp-4a.py’)

##

Fig. 4:  Minimal data processing: I.1, I.2, I.5, I.7, I.8, the first two “mean-building” steps from IV.a, all steps in V, and VIII.

Run: $ python fig4_plot-mill2-hster-ao-mean-4b-plus-ctl-cmp.py
or inside Ipython: execfile(‘fig4_plot-mill2-hster-ao-mean-4b-plus-ctl-cmp.py’)

##

Fig. 5:  Minimal data processing: I.1, I.2, I.5, I.7, IV., and V.a

Run: $ python fig5_plot-non-tsteric-resid-3.py
or inside Ipython: execfile(‘fig5_plot-non-tsteric-resid-3.py’)

##

Fig. 6:  Minimal data processing: I.3, I.7, IV.a and V.a.  If you want to calculate the freshwater flux files yourself, then also do the following steps: I.9, I.11, II.18, II.19, and VI.

Run: $ python fig6_plot-subcomp-hssh-cmp-4_cm.py
or inside Ipython: execfile(‘fig6_plot-subcomp-hssh-cmp-4_cm.py’)

##

Fig. 7:  Minimal data processing: I.3, I.4, I.7, I.8., II.13, II.14, III.20, III.21, IV.a, V.a, and VIII.  If you want to calculate the freshwater flux files yourself, then also do the following steps: I.9, I.10, I.11, I.12, II.16, II.17, II.18, II.19, VI, and IX.

Run: $ python fig7_past1000-ctl-cmp-6pan-3-p.py
or inside Ipython: execfile(‘fig7_past1000-ctl-cmp-6pan-3-p.py’)

##

Fig. 8:  Minimal data processing: I.3, I.4, III.22, III.23, III.24, and III.25. If you want to calculate the freshwater flux files yourself (which contain the ice flux part needed here), then also do the following steps: I.7, I.8, I.9, I.10, I.11, I.12, II.16, II.17, II.18, II.19, VI, and IX. 

Run: $ python fig8_point-correl-maps-3-3panel-left-3p.py
or inside Ipython: execfile(‘fig8_point-correl-maps-3-3panel-left-3p.py’)

##

Fig. 9:  Minimal data processing: II.15 and VII. If you want to calculate the freshwater flux files yourself (which contain the ice flux part needed here), then also do the following steps: I.7, I.9, I.11, II.18, II.19, VI. 

Run: $ python fig9_plot-tas-iceflux-3.py
or inside Ipython: execfile(‘fig9_plot-tas-iceflux-3.py’)

##


That’s it.  Refer to the paper for any questions you might have about what we did and why. I may not be available to answer questions about these scripts or accessing the data.  Regarding this research in particular, if you really are unclear or concerned about something we did for this paper, I will attempt to answer.  Write me at the corresponding author’s email in the paper.

Cheers,
Mark Carson

06-June-2022



Citation:  Carson, M., Köhl, A., & Stammer, D. (2022). Century-Scale Variability of Arctic SSH and Freshwater Content in a Past-1000-Year Model Experiment, Journal of Climate, 35(13), 4265-4276. Retrieved Jun 6, 2022, from https://journals.ametsoc.org/view/journals/clim/35/13/JCLI-D-21-0484.1.xml


