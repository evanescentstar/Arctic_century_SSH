## arc-icethick-flux-1_*.py -- Calculate the (gradient of?) ice thickness
##  across the same line as the ice transport to see if this is the
##  dominant feature of the ice transport

from ferr import use
import netCDF4 as nc4
import numpy as np
import sys
import collections

d2 = use('basin_fx_MPI-ESM-P_past1000_r0i0p0.nc')
bas = d2.gv('basin')
latv2 = d2.v['lat_vertices'][:]
lonv2 = d2.v['lon_vertices'][:]
lat2 = d2.v['lat'][:]
lon2 = d2.v['lon'][:]

basshp = np.array(bas[:100].shape)
basshp[0] = basshp[0] - 1
basshp[1] = basshp[1] - 1
bas1 = bas[:100]

output = collections.OrderedDict()

## i1 is the Greenland to Svalbard line

i1 = np.array([[224, 35],  # 1
               [223, 36],  # 2
               [222, 37],  # 3
               [221, 38],  # 4
               [220, 39],  # 5
               [219, 40],  # 6
               [218, 41],  # 7
               [217, 42],  # 8
               [216, 43]], dtype=np.int32)  # 9

## i2 is the Svalbard to Norway, plus Bering Strait

i2 = np.array([[207, 49],  # 10
               [206, 50],  # 11
               [205, 51],  # 12
               [204, 52],  # 13
               [203, 53],  # 14
               [202, 54],  # 15
               [201, 55],  # 16
               [200, 56],  # 17
               [199, 57],  # 18
               [198, 58],  # 19
               [197, 59],  # 20
               [7, 84]], dtype=np.int32)  # 21

#
iall = np.r_[i1, i2]
iall = zip(iall[:, 1], iall[:, 0])
ix = np.array(iall)

for j, i in iall:
    if (i == 215) and (j == 43):  ## to the east
        output[(j, i)] = 1
    elif (i == 224) and (j == 34):  ## to the south
        output[(j, i)] = 3
    else:  ## to both
        output[(j, i)] = 5

dg = use('GR15L40_fx.nc')
a2 = dg.gv('area')

dlxu = dg.gv('dlxu')
dlxv = dg.gv('dlxv')
dlxp = dg.gv('dlxp')

dlyu = dg.gv('dlyu')
dlyv = dg.gv('dlyv')
dlyp = dg.gv('dlyp')

deute = dg.gv('deute')  # depth_at_u_vector_point
deuto = dg.gv('deuto')  # depth_at_v_vector_point
ddue = dg.gv('ddue')  # ocean_level_thickness_at_v_vector_point
dduo = dg.gv('dduo')  # ocean_level_thickness_at_u_vector_point

dthk = nc4.MFDataset('ice/sim_ann_MPI-ESM-P_past1000*.nc')
tax = dthk.variables['time'][:]
taxbnds = dthk.variables['time_bnds'][:]
latthk = dthk.variables['lat'][:]
lonthk = dthk.variables['lon'][:]

thk = dthk.variables['sim']

tlen = thk.shape[0]

iall = output.keys()
ix = np.array(iall)

outlen = len(iall)
icethk = np.ma.masked_all((outlen, tlen), dtype=np.float32)
lats = np.zeros((outlen,), dtype=np.float64)
lons = np.zeros((outlen,), dtype=np.float64)

i = 0

print "\nData gathered; files opened.  Ready to start main loop\n"
sys.stdout.flush()

for key in iall:
    print "\nk: %d,%d\n" % (key[0], key[1])
    k1 = tuple(key)
    loc1 = output[k1]
    print 'loc = %d\n' % loc1
    sys.stdout.flush()

    icethk[i, :] = thk[:, key[0], key[1]] * a2[key[0], key[1]]

    i = i + 1

np.save('icethk_1_svalbard.npy', icethk.data)

type1 = 'sim'
v1_cellmeth = dthk.variables[type1].cell_methods
v1_cellmeas = dthk.variables[type1].cell_measures

lons = lon2[ix[:, 0], ix[:, 1]]
lats = lat2[ix[:, 0], ix[:, 1]]

nfname = 'icethk_arc_1_svalbard.nc'

dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
dcur1.createDimension('ix', outlen)
dcur1.createDimension('time', 1000)
dcur1.createDimension('bnds', 2)

dcur1.history = 'created by script: %s' % 'arc-icethick-flux-1_svalbard.py'

time_var = dcur1.createVariable('time', 'd', ('time',))
time_var.long_name = 'time'
time_var.standard_name = 'time'
time_var.units = 'days since 0001-01-01 00:00:00'
time_var.bounds = 'time_bnds'
time_var.calendar = 'proleptic_gregorian'
time_var.axis = 'T'
time_var[:] = tax

timebnd_var = dcur1.createVariable('time_bnds', 'd', ('time', 'bnds'))
timebnd_var[:] = taxbnds

lat_var = dcur1.createVariable('lats', 'd', ('ix',))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var[:] = lats

lon_var = dcur1.createVariable('lons', 'd', ('ix',))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var[:] = lons

var1_var = dcur1.createVariable('thk', 'f', ('ix', 'time'), fill_value=-1e34)
var1_var.long_name = 'sea ice mass'
var1_var.standard_name = 'simass'
var1_var.units = 'kg'
var1_var.cell_methods = v1_cellmeth
var1_var.cell_measures = v1_cellmeas
var1_var.missing_value = np.float32(-1e34)

icethk.data[icethk.mask] = -1e34
var1_var[:] = icethk[:].copy()

dcur1.sync()
dcur1.close()
