import mcmath
import mcp
from ferr import use
import netCDF4 as nc4
from datetime import datetime as dt
import numpy as np
import scipy as sp
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import cm

# Index location of the cross in panel a
j1 = 44
i1 = 226

d1 = nc4.MFDataset('zos/zos_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')
lonv1 = d1.variables['lon_vertices'][:]
latv1 = d1.variables['lat_vertices'][:]
lon = d1.variables['lon'][:]
lat = d1.variables['lat'][:]
tax = d1.variables['time'][:]

xax = lonv1
yax = latv1

zos = d1.variables['zos'][:]

zos_dt = mcmath.my_dtrnd(zos, np.arange(1000.)) * 100
zos_lf_11 = mcmath.rm_calc(zos_dt, 'h', 11, 1)[1]
tax1 = tax[5:-5]

dp = nc4.MFDataset('control/zos/zos_ann_MPI-ESM-P_piC*.nc')
taxp = dp.variables['time'][:]
tpsz = taxp.size

zosp = dp.variables['zos'][:]

zosp_dt = mcmath.my_dtrnd(zosp, np.arange(tpsz)) * 100
zosp_lf_11 = mcmath.rm_calc(zosp_dt, 'h', 11, 1)[1]
tax1p = taxp[5:-5]

dbas = use('basin_fx_MPI-ESM-P_past1000_r0i0p0.nc')
bas = dbas.gv('basin')

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')

# ~ bnds = (arange(12)).tolist()
# ~ norm = mpl.colors.BoundaryNorm(bnds,256)
# ~ pcolormesh(bas,norm=norm)

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

ao_msk = amsk
ao_area = ao_msk * area
awgt = ao_area / ao_area.max()
awgt1 = np.sqrt(awgt)

# -- ctlp

ao_datp = zosp_lf_11 * ao_msk.reshape(1, 220, 256)
ao_datp = ao_datp * awgt1.reshape(1, 220, 256)

ntimep = ao_datp.shape[0]
Nhalfp = 1. / np.sqrt(ntimep)
scaler = 0.93

blahp = mcmath.tyx2tm_arr(ao_datp)

locp = blahp[1]

[Up, Sp, Vp] = sp.linalg.svd(blahp[0].data, full_matrices=0)

eofsp = np.ma.masked_all((7, 220, 256))

eofsp = mcmath.tm2tyx_arr(Vp[:7], locp, (220, 256)) / awgt1.reshape(220, 256)
pcsp = Up[:, :7] / Nhalfp
Dsp = Nhalfp * eofsp * Sp[:7].reshape(7, 1, 1)

lambp = Sp ** 2 / ntimep
M1p = (lambp[0] / lambp.sum()) * 100
M2p = (lambp[1] / lambp.sum()) * 100
M3p = (lambp[2] / lambp.sum()) * 100

lambpnorm = lambp / lambp.sum()

# -- end ctlp

# -- past1000

ao_dat = zos_lf_11 * ao_msk.reshape(1, 220, 256)
ao_dat = ao_dat * awgt1.reshape(1, 220, 256)

ntime = ao_dat.shape[0]
Nhalf = 1. / np.sqrt(ntime)
scaler = 0.93

blah = mcmath.tyx2tm_arr(ao_dat)

loc = blah[1]

[U, S, V] = sp.linalg.svd(blah[0].data, full_matrices=0)

eofs = np.ma.masked_all((7, 220, 256))

eofs = mcmath.tm2tyx_arr(V[:7], loc, (220, 256)) / awgt1.reshape(220, 256)
pcs = U[:, :7] / Nhalf
Ds = Nhalf * eofs * S[:7].reshape(7, 1, 1)

lamb = S ** 2 / ntime
M1 = (lamb[0] / lamb.sum()) * 100
M2 = (lamb[1] / lamb.sum()) * 100
M3 = (lamb[2] / lamb.sum()) * 100

lambnorm = lamb / lamb.sum()

# -- end past1000


###  PLOTTING


fig = plt.figure(figsize=(10, 6))

# subplot placements
rect_bll = 0.011, 0.08, 0.220, 0.39
rect_blr = 0.260, 0.13, 0.225, 0.30
rect_brl = 0.511, 0.08, 0.220, 0.39
rect_brr = 0.760, 0.13, 0.225, 0.30

rect_ull = 0.011, 0.55, 0.220, 0.39
rect_ulr = 0.260, 0.60, 0.225, 0.30
rect_url = 0.511, 0.55, 0.220, 0.39
rect_urr = 0.760, 0.60, 0.225, 0.30

ex = 0.025
xe = 0.015
sx = 0.015

# text placements
titl_plc = (0.09, 1.03)
rtxt_plc = (0.00, 0.98)
lett_plc = (-0.02, 1.02)

titlsz = 10

# 

## panel titles

t1a = 'Past1000 SSH EOF 1, 11-yrm'
t1c = 'CTL-P SSH EOF 1, 11-yrm'
t1e = 'Past1000 SSH EOF 2, 11-yrm'
t1b = 'Past1000 SSH PC ts 1, 11-yrm'
t1d = 'CTL-P SSH PC ts 1, 11-yrm'
t1f = 'Past1000 SSH PC ts 2, 11-yrm'
t1g = 'CTL-P SSH EOF 2, 11-yrm'
t1h = 'CTL-P SSH PC ts 2, 11-yrm'

cmapuse = cm.RdBu_r
v1 = -4.
v2 = 4.0

w1 = 8500000
h1 = 5000000
lon_0 = 315
lat_0 = None
proj1 = 'npl'
blat1 = 70

yl1 = 100
tcksz = 10
fylim1 = (-3.16, 3.16)
fxlim1 = None
xadj = -0.0

xlam = 0.8
ylam = 0.91

################ A
axa = fig.add_axes(rect_ull)
m1, cs = mcp.cvshade(xax, yax, Ds[0] * (-1), lon0=lon_0, blat=blat1, lat0=lat_0, vlo=v1, vhi=v2, cmap=cmapuse,
                     land1='darkgrey', proj=proj1, wid=w1, ht=h1, add=1, nocb=True)

lon1 = lon[j1, i1]
lat1 = lat[j1, i1]
x1, y1 = m1(lon1, lat1)

var_a = '%.1f' % (lambnorm[0] * 100)

plt.text(x1, y1, '$\dagger$', ha='center', va='center', color='white', size=10, fontweight='bold')
plt.text(x1, y1, '$\dagger$', ha='center', va='center', color='white', size=10, fontweight='bold')
plt.text(xlam, ylam, var_a, bbox=dict(facecolor='white', edgecolor='white'), ha='center', va='center', color='black',
         size=10, fontweight='bold', transform=axa.transAxes)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1a, ha='left', size=titlsz, transform=axa.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'a.)', ha='left', va='bottom', size=10, transform=axa.transAxes)

ax_a = fig.add_axes((0.01, 0.52, 0.1, 0.1))
plt.plot(np.arange(8.), lambnorm[:8], 'o', ms=3, color='darkblue')
ax_a.set_xlim(-0.5, 8.5)
ax_a.set_xticklabels('')
ax_a.set_yticklabels('')
ax_a.tick_params(length=0)
ylims = ax_a.get_ylim()
ax_a.set_ylim(ylims[0], ylims[1] + 0.05)

###


################ B
axb = fig.add_axes(rect_ulr)
mcp.dateplt_m(tax1, pcs[:, 0] * (-1), yl=yl1, fxlim=None, fylim=fylim1, ticksize=tcksz, nomth=True, fmt='-',
              color='#ff7f0e')

dt1 = mcmath.n2d(tax1)
xlist = dt1[95::100]
axb1 = plt.gca()
axb1.set_xlim(dt(900, 1, 1), dt(1800, 1, 1))
axb1.set_xticks(xlist)

plt.text(titl_plc[0], titl_plc[1], t1b, ha='left', size=titlsz, transform=axb.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'b.)', ha='left', va='bottom', size=10, transform=axb.transAxes)

###


################ C
axc = fig.add_axes(rect_url)
m1_c, cs = mcp.cvshade(xax, yax, Dsp[0] * (-1), lon0=lon_0, blat=blat1, lat0=lat_0, vlo=v1, vhi=v2, cmap=cmapuse,
                       land1='darkgrey', proj=proj1, wid=w1, ht=h1, add=1, nocb=True)

var_c = '%.1f' % (lambpnorm[0] * 100)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1c, ha='left', size=titlsz, transform=axc.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'c.)', ha='left', va='bottom', size=10, transform=axc.transAxes)
plt.text(xlam, ylam, var_c, bbox=dict(facecolor='white', edgecolor='white'), ha='center', va='center', color='black',
         size=10, fontweight='bold', transform=axc.transAxes)

ax_ap = fig.add_axes((0.51, 0.52, 0.1, 0.1))
plt.plot(np.arange(8.), lambpnorm[:8], 'o', ms=3, color='darkblue')
ax_ap.set_xlim(-0.5, 8.5)
ax_ap.set_xticklabels('')
ax_ap.set_yticklabels('')
ax_ap.tick_params(length=0)
ylimsp = ax_ap.get_ylim()
ax_ap.set_ylim(ylimsp[0], ylimsp[1] + 0.05)

###


################ D
axd = fig.add_axes(rect_urr)
mcp.dateplt_m(tax1p[50:1050], pcsp[50:1050, 0] * (-1), yl=yl1, fxlim=fxlim1, fylim=fylim1, ticksize=tcksz, nomth=True,
              fmt='-',
              color='#ff7f0e')

plt.text(titl_plc[0], titl_plc[1], t1d, ha='left', size=titlsz, transform=axd.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'd.)', ha='left', va='bottom', size=10, transform=axd.transAxes)

###

################ E
axe = fig.add_axes(rect_bll)
m1, cs = mcp.cvshade(xax, yax, Ds[1], lon0=lon_0, blat=blat1, lat0=lat_0, vlo=v1, vhi=v2, cmap=cmapuse,
                     land1='darkgrey', proj=proj1, wid=w1, ht=h1, add=1, nocb=True)

var_e = '%.1f' % (lambnorm[1] * 100)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1e, ha='left', size=titlsz, transform=axe.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'e.)', ha='left', va='bottom', size=10, transform=axe.transAxes)
plt.text(xlam, ylam, var_e, bbox=dict(facecolor='white', edgecolor='white'), ha='center', va='center', color='black',
         size=10, fontweight='bold', transform=axe.transAxes)

###


################ F
axf = fig.add_axes(rect_blr)
mcp.dateplt_m(tax1, pcs[:, 1], yl=yl1, fxlim=None, fylim=fylim1, ticksize=tcksz, nomth=True, fmt='-', color='#ff7f0e')

axf = plt.gca()
axf.set_xlim(dt(900, 1, 1), dt(1800, 1, 1))
axf.set_xticks(xlist)
axf.set_xticklabels('')

plt.text(titl_plc[0], titl_plc[1], t1f, ha='left', size=titlsz, transform=axf.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'f.)', ha='left', va='bottom', size=10, transform=axf.transAxes)

###

################ G
axg = fig.add_axes(rect_brl)
m1, cs = mcp.cvshade(xax, yax, Dsp[1], lon0=lon_0, blat=blat1, lat0=lat_0, vlo=v1, vhi=v2, cmap=cmapuse,
                     land1='darkgrey', proj=proj1, wid=w1, ht=h1, add=1, nocb=True)

var_g = '%.1f' % (lambpnorm[1] * 100)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1g, ha='left', size=titlsz, transform=axg.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'g.)', ha='left', va='bottom', size=10, transform=axg.transAxes)
plt.text(xlam, ylam, var_g, bbox=dict(facecolor='white', edgecolor='white'), ha='center', va='center', color='black',
         size=10, fontweight='bold', transform=axg.transAxes)

###


################ H
ax = fig.add_axes(rect_brr)
mcp.dateplt_m(tax1p[50:1050], pcsp[50:1050, 1], yl=yl1, fxlim=fxlim1, fylim=fylim1, ticksize=tcksz, nomth=True, fmt='-',
              color='#ff7f0e')
ax.set_xticklabels('')

plt.text(titl_plc[0], titl_plc[1], t1h, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'h.)', ha='left', va='bottom', size=10, transform=ax.transAxes)

###


## at bottom
ax2 = fig.add_axes((0.30, 0.04, 0.4, 0.02))
norm = mpl.colors.Normalize(vmin=v1, vmax=v2)
cb2 = mpl.colorbar.ColorbarBase(ax2, cmap=cmapuse,
                                norm=norm,
                                extend='both',
                                ticks=np.linspace(v1, v2, num=np.int((v2 - v1) / 2 + 1)),  # optional
                                spacing='proportional',
                                orientation='horizontal')

xtl = ax2.get_xticklabels()
plt.setp(xtl, 'size', 12)

plt.text(1., 0.5, '(cm)', ha='left', va='top', size=11, transform=ax2.transAxes)

plt.savefig('fig3_ssh-eof-ctlcmp-4.png', dpi=300)
