import netCDF4 as nc4
from ferr import use
import numpy as np

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

dso2 = nc4.MFDataset('control/so/so_ann*.nc')
so2 = dso2.variables['so'][:,:,30:85]

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[30:85]
area1 = area[30:85]
area1m = area1*ao_msk1

so2m = so2*ao_msk1.reshape(1,1,55,256)

fwf2 = (35.0 - so2m) / 35.

dvol = use('volcello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
vol = dvol.v['volcello'][:,30:85]

# vol.count()
# fwf2.count()

fwvol2 = fwf2*vol.reshape(1,40,55,256)

fwtot2 = fwvol2.sum(axis=3).sum(axis=2).sum(axis=1)

fwarccm2 = fwtot2 / area1m.sum()

fw2 = np.array(fwarccm2)
save('fwtot_control.npy',fw2)

fwvol2_da = fwvol2.sum(axis=1)
fwht2 = fwvol2_da / area1m.reshape(1,55,256)
save('fwht_control.npy',fwht2.data)
