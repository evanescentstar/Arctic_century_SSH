import mcmath
import mcp
from ferr import use
import netCDF4 as nc4
from datetime import datetime as dt
import numpy as np
from matplotlib import pyplot as plt

from matplotlib import font_manager

prop1 = font_manager.FontProperties(size=8)
dts = use('tsteric-ssh-zmn.nc')
dhs = use('hsteric-ssh-zmn-3.nc')

j1 = 44
i1 = 226

ts = dts.gv('ssh')
hs = dhs.gv('ssh')

dbas = use('basin_fx_MPI-ESM-P_past1000_r0i0p0.nc')
bas = dbas.gv('basin')

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
area.mask = ts[0].mask.copy()

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]
ao_msk = amsk
ao_area = ao_msk * area
awgt = ao_area / ao_area.max()
awgt1 = np.ma.sqrt(awgt)

tsmn = (ts * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()
hsmn = (hs * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

zst = (ts + hs) * 100  # already in cm

zst_gmn = (zst * area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / (area).sum()
zst_gmn = zst_gmn - zst_gmn.mean()
zst_gmn_dt = mcmath.my_dtrnd(zst_gmn, np.arange(1000))
zst_gmn_dt = zst_gmn_dt - zst_gmn_dt.mean()

d2 = nc4.MFDataset('zos/zos_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')  ## from d2, forced
zos2 = d2.variables['zos'][:]
zos2_dt = mcmath.my_dtrnd(zos2, np.arange(1000.))
zos2_dta = zos2_dt - zos2_dt.mean()
zos_gm = (zos2_dta * area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / (area).sum()
zos_gm = zos_gm - zos_gm.mean()
# zos_zero = zos2_dta - zos_gm.reshape(1000,1,1)
zos_zero = zos2_dta

zao2mn = (zos_zero * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()
zao2mn_dt = mcmath.my_dtrnd(zao2mn, np.arange(1000))

tsmn_dt = mcmath.my_dtrnd(tsmn, np.arange(1000))
hsmn_dt = mcmath.my_dtrnd(hsmn, np.arange(1000))
resid = zao2mn_dt - tsmn_dt - hsmn_dt

tax = dhs.dt_vals('ssh')

resid_anom_cm = (resid - resid.mean()) * 100

# mcp.dateplt_m(tax,resid_anom_cm,yl=100,nomth=True)
# ylabel('sea level anomaly (cm)')
# title('Non-steric SSH')

# resid_anom_cm_41 = mcmath.rm_calc(resid_anom_cm,'h',41,1)[1]
# mcp.dateplt_m(tax[20:-20],resid_anom_cm_41,yl=100,nomth=True,fmt='r-')

resid_anom_cm_11 = mcmath.rm_calc(resid_anom_cm, 'h', 11, 1)[1]
tsmn_dt_cm_11 = mcmath.rm_calc(tsmn_dt * 100, 'h', 11, 1)[1]
tsmn_dta_cm_11 = tsmn_dt_cm_11 - tsmn_dt_cm_11.mean()
hsmn_dt_cm_11 = mcmath.rm_calc(hsmn_dt * 100, 'h', 11, 1)[1]
hsmn_dta_cm_11 = hsmn_dt_cm_11 - hsmn_dt_cm_11.mean()

resid_dt_cm_11 = mcmath.my_dtrnd(resid_anom_cm_11, np.arange(990))
resid_dta_cm_11 = resid_dt_cm_11 - resid_dt_cm_11.mean()
ind1, zst_gmn_dt_11 = mcmath.rm_calc(zst_gmn_dt, 'h', 11, 1)

zspot = zos_zero[:, j1, i1]
tspot = ts[:, j1, i1]
hspot = hs[:, j1, i1]
resid_spot = zspot - tspot - hspot

tspot_dt_cm = mcmath.my_dtrnd(tspot * 100, np.arange(1000))
resid_spot_dt_cm = mcmath.my_dtrnd(resid_spot * 100, np.arange(1000))
tspot_dt_cm_11 = mcmath.rm_calc(tspot_dt_cm, 'h', 11, 1)[1]
resid_spot_dt_cm_11 = mcmath.rm_calc(resid_spot_dt_cm, 'h', 11, 1)[1]
tspot_dta_cm_11 = tspot_dt_cm_11 - tspot_dt_cm_11.mean()
resid_spot_dta_cm_11 = resid_spot_dt_cm_11 - resid_spot_dt_cm_11.mean()

hspot_dt_cm = mcmath.my_dtrnd(hspot * 100, np.arange(1000))
hspot_dt_cm_11 = mcmath.rm_calc(hspot_dt_cm, 'h', 11, 1)[1]
hspot_dta_cm_11 = hspot_dt_cm_11 - hspot_dt_cm_11.mean()

##### Plotting
fig = plt.figure(figsize=(3.5, 6.0))

# text placements
titl_plc = (0.5, 1.03)
rtxt_plc = (0.00, 0.98)
lett_plc = (0.0, 1.02)

# subplot placements
rect_t = 0.12, 0.70, 0.83, 0.27
rect_m = 0.12, 0.38, 0.83, 0.27
rect_b = 0.12, 0.07, 0.83, 0.27

ex = 0.025
xe = 0.015
sx = 0.015

################ B
axa = fig.add_axes(rect_m)

tax1 = tax[5:-5]

fylim1 = 4
fylim2 = 40.0

line3 = mcp.dateplt_m(tax1, hsmn_dta_cm_11, yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)), fylim=(-1 * fylim1, fylim1),
                      nomth=True, label='Arctic mean halosteric SSH (cm)', fmt='-')
line1 = mcp.dateplt_m(tax1, tsmn_dta_cm_11, yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)), fylim=(-1 * fylim1, fylim1),
                      nomth=True, label='Arctic mean thermosteric SSH (cm)', fmt='m-')
line2 = mcp.dateplt_m(tax1, resid_dta_cm_11, yl=100, fxlim=(850, 1850), fylim=(-1 * fylim1, fylim1), nomth=True,
                      label='Arctic mean non-steric SSH (cm)', fmt='g-')

xlist = tax1[95::100]

axa.set_xticklabels('')
axa.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axa.set_xticks(xlist)
plt.text(lett_plc[0], lett_plc[1], 'b.)', ha='left', va='bottom', size=10, transform=axa.transAxes)
# ylabel('cm',size=10,va='center')

# title('Forced-run, 11-yr running means',size=9)

plt.legend(loc=4, prop=prop1)

################ C
axb = fig.add_axes(rect_b)

line3 = mcp.dateplt_m(tax1, hspot_dta_cm_11, yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)), fylim=(-1 * fylim2, fylim2),
                      nomth=True, label='$\dagger$ halosteric SSH (cm)', fmt='-')
line1 = mcp.dateplt_m(tax1, tspot_dta_cm_11, yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)), fylim=(-1 * fylim2, fylim2),
                      nomth=True, label='$\dagger$ thermosteric SSH (cm)', fmt='m-')
line2 = mcp.dateplt_m(tax1, resid_spot_dta_cm_11, yl=100, fxlim=(850, 1850), fylim=(-1 * fylim2, fylim2), nomth=True,
                      label='$\dagger$ non-steric SSH (cm)', fmt='g-')

plt.legend(loc=4, prop=prop1)
axb.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axb.set_xticks(xlist)
# ylabel('SSH, cm',size=10,va='top')
plt.text(lett_plc[0], lett_plc[1], 'c.)', ha='left', va='bottom', size=10, transform=axb.transAxes)

################ A
axa = fig.add_axes(rect_t)

line1 = mcp.dateplt_m(tax[ind1], resid_anom_cm_11, yl=100, nomth=True, fmt='-', color='green', lw=1,
                      label='Arctic mean non-steric SSH')
line2 = mcp.dateplt_m(tax[ind1], zst_gmn_dt_11 * -1.0, yl=100, nomth=True, fmt='-', color='firebrick', lw=1,
                      label='-1 * global mean steric SSH')
# ylabel('sea level (cm)')
# title('Arctic mean ssh comparison\nzero glob mean, 21-yrm',size=9)
plt.legend(loc=2, prop=prop1)

axa.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axa.set_xticks(xlist)
axa.set_xticklabels('')
plt.text(lett_plc[0], lett_plc[1], 'a.)', ha='left', va='bottom', size=10, transform=axa.transAxes)

plt.savefig('fig5_non-steric-ssh-3c-11.png', dpi=300)
