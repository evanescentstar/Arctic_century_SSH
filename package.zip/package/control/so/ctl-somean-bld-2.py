import netCDF4 as nc4
import numpy as np

scriptname = 'ctl-somean-bld-2.py'
fname = 'so_ann*.nc'

somn = np.ma.zeros((40, 220, 256), dtype=np.float32)

j = 0

d1 = nc4.MFDataset(fname)

lat = d1.variables['lat'][:]
lon = d1.variables['lon'][:]
latv = d1.variables['lat_vertices'][:]
lonv = d1.variables['lon_vertices'][:]
lev = d1.variables['lev'][:]
lev_bnds = d1.variables['lev_bnds'][:]

for i in xrange(40):
    so1 = d1.variables['so'][:, i]
    somn[i] = so1.mean(axis=0)
    j = j + 1

d1.close()

nfname = 'ctl-so_mean.nc'

dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
dcur1.createDimension('j', lat.shape[0])
dcur1.createDimension('i', lat.shape[1])
dcur1.createDimension('lev', 40)
dcur1.createDimension('bnds', 2)
dcur1.createDimension('vertices', 4)

dcur1.history = 'created by script: %s' % scriptname
dcur1.processed_file = '%s' % fname

lat_var = dcur1.createVariable('lat', 'd', ('j', 'i'))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var.bounds = 'lat_vertices'
lat_var[:] = lat

lon_var = dcur1.createVariable('lon', 'd', ('j', 'i'))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var.bounds = 'lon_vertices'
lon_var[:] = lon

latbnd_var = dcur1.createVariable('lat_vertices', 'd', ('vertices', 'j', 'i'))
latbnd_var.units = 'degrees_north'
latbnd_var[:] = latv

lonbnd_var = dcur1.createVariable('lon_vertices', 'd', ('vertices', 'j', 'i'))
lonbnd_var.units = 'degrees_east'
lonbnd_var[:] = lonv

lev_var = dcur1.createVariable('lev', 'd', ('lev',))
lev_var.bounds = "lev_bnds"
lev_var.units = "m"
lev_var.axis = "Z"
lev_var.positive = "down"
lev_var.long_name = "ocean depth coordinate"
lev_var.standard_name = "depth"
lev_var[:] = lev

levbnds_var = dcur1.createVariable('lev_bnds', 'd', ('lev', 'bnds'))
levbnds_var[:] = lev_bnds

var1_var = dcur1.createVariable('so', 'f', ('lev', 'j', 'i'), fill_value=-1e34)
var1_var.long_name = "Sea Water Salinity"
var1_var.standard_name = "sea_water_salinity"
var1_var.units = "psu"
var1_var.cell_methods = "time: mean"
var1_var.cell_measures = "area: areacello volume: volcello"
var1_var.coordinates = "lat lon"
var1_var.missing_value = np.float32(-1e34)

somn.data[somn.mask] = -1e34
var1_var[:] = somn[:].copy()

dcur1.sync()
dcur1.close()
