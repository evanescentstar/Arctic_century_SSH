import numpy as np
from ferr import use
import netCDF4 as nc4
import seawater
import mcmath

scriptname = 'ctl-hsteric-bld-1.py'

fname = 'so/so_ann_MPI-ESM-P_piControl_r1i1p1_*.nc'
outdir = '.'
var1 = 'mean'
sizes = []

#### local mean alph_T and depth thicknesses

dtem = use('thetao/ctl-thetao_mean.nc')

tmn = dtem.v['thetao'][:]
z1 = dtem.d['lev'][:]
z2 = z1.reshape((-1, 1, 1))
zbnds = dtem.d['lev_bnds'][:]
zlen = z1.size
lon = dtem.v['lon'][:]
lat = dtem.v['lat'][:]
lonv = dtem.v['lon_vertices'][:]
latv = dtem.v['lat_vertices'][:]

dg = use('GR15L40_fx.nc')
a2 = dg.gv('area')

dlxu = dg.gv('dlxu')
dlxv = dg.gv('dlxv')
dlxp = dg.gv('dlxp')

dlyu = dg.gv('dlyu')
dlyv = dg.gv('dlyv')
dlyp = dg.gv('dlyp')

ddpo = dg.gv('ddpo')  # ocean_level_thickness_at_pressure_point

dsal = use('so/ctl-so_mean.nc')
somn = dsal.v['so'][:]

tmn = tmn - 273.15

beta_T = seawater.beta(somn, tmn, z2, True)

#### open 4-d datafile

d1 = nc4.MFDataset(fname, 'r')

t1 = d1.variables['time'][:]
dt1 = mcmath.n2d(t1)
tbnds1 = d1.variables['time_bnds'][:]

#### open and define output file

outfile = 'ctl-hsteric-heights-1.nc'

dcur1 = nc4.Dataset(outfile, 'w')
dcur1.createDimension('time', None)
dcur1.createDimension('j', lat.shape[0])
dcur1.createDimension('i', lat.shape[1])
dcur1.createDimension('lev', 40)
dcur1.createDimension('bnds', 2)
dcur1.createDimension('vertices', 4)

dcur1.history = 'created by script: %s' % scriptname
dcur1.processed_file = '%s' % fname

time_var = dcur1.createVariable('time', 'd', ('time',))
time_var.long_name = 'time'
time_var.standard_name = 'time'
time_var.units = 'days since 0001-01-01 00:00:00'
time_var.bounds = 'time_bnds'
time_var.calendar = 'proleptic_gregorian'
time_var.axis = 'T'
time_var[:] = t1

timebnd_var = dcur1.createVariable('time_bnds', 'd', ('time', 'bnds'))
timebnd_var[:] = tbnds1

lat_var = dcur1.createVariable('lat', 'd', ('j', 'i'))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var.bounds = 'lat_vertices'
lat_var[:] = lat

lon_var = dcur1.createVariable('lon', 'd', ('j', 'i'))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var.bounds = 'lon_vertices'
lon_var[:] = lon

latbnd_var = dcur1.createVariable('lat_vertices', 'd', ('vertices', 'j', 'i'))
latbnd_var.units = 'degrees_north'
latbnd_var[:] = latv

lonbnd_var = dcur1.createVariable('lon_vertices', 'd', ('vertices', 'j', 'i'))
lonbnd_var.units = 'degrees_east'
lonbnd_var[:] = lonv

lev_var = dcur1.createVariable('lev', 'd', ('lev',))
lev_var.bounds = "lev_bnds"
lev_var.units = "m"
lev_var.axis = "Z"
lev_var.positive = "down"
lev_var.long_name = "ocean depth coordinate"
lev_var.standard_name = "depth"
lev_var[:] = z1

levbnds_var = dcur1.createVariable('lev_bnds', 'd', ('lev', 'bnds'))
levbnds_var[:] = zbnds

h_var = dcur1.createVariable('ssh', 'f', ('time', 'lev', 'j', 'i'), fill_value=-1e34)
h_var.long_name = 'halosteric delta ssh component'
h_var.units = 'm'
h_var.missing_value = np.float32(-1e34)

#### calc and write per z-level

for k in xrange(zlen):
    Sal1 = d1.variables['so'][:, k, :, :]
    DSal1 = Sal1 - somn[k]  # delta S
    del_h = -1 * ddpo[k] * beta_T[k].reshape(1, lon.shape[0], lon.shape[1]) * DSal1
    h_var[:, k] = del_h

dcur1.sync()
dcur1.close()

d1.close()
