import numpy as np
import netCDF4 as nc4
import mcmath
from mcmath import n2d, d2n
import sys
import re
from glob import glob

scriptname = sys.argv[0]

if len(sys.argv) < 2:
	print "\n\tusage: python %s <monthly data file name; can have wildcard>\n" % sys.argv[0]
	exit()

omon_re = re.compile(r'(\w+)_Omon_(.*)')
oimon_re = re.compile(r'(\w+)_OImon_(.*)')

# Linux appears to glob the * into filenames at the command prompt, passing
# the whole resultant file list into sys.argv. Windows apparently passes the
# wildcard to the program.  Thus the different treatments here.  In either OS,
# you can pass either one filename, or one filename with an * which will glob
# to all the files you want to process at once in that directory.  This
# behavior should work in either Linux or Windows.  Didn't test on MacOS.
if len(sys.argv) == 2:
	files1 = glob(sys.argv[1])
else:
	files1 = sys.argv[1:]

flen = len(files1)

if flen == 0:
	print "\n\tusage: python %s <data file name; can have wildcard>\n\t		e.g., python %s data.ghg-cc.*.1850-2005.nc\n" % (
		scriptname, scriptname)
	exit()

print "f1 is %s\n" % files1[0]

if (omon_re.match(files1[0]) is None) and (oimon_re.match(files1[0]) is None):
	print "\nIncorrect data wildcard filename provided for files: \'%s\'\n\n" % files1[0]
	exit()

if omon_re.match(files1[0]) is not None:
	type1 = omon_re.match(files1[0]).groups()[0]
	fnpart1 = omon_re.match(files1[0]).groups()[1]
else:
	type1 = oimon_re.match(files1[0]).groups()[0]
	fnpart1 = oimon_re.match(files1[0]).groups()[1]

print '\n%s\n' % type1
print '\n%s\n' % fnpart1

nfname = type1 + "_ann_" + fnpart1

print nfname

nocellmeas = ['transix', 'transiy']

d1 = nc4.Dataset(files1[0])
t1 = d1.variables['time'][:]
dt1 = n2d(t1, units=d1.variables['time'].units)
tbnds = d1.variables['time_bnds'][:]
dtbnds = n2d(tbnds, units=d1.variables['time'].units)
tax, taxbnds = mcmath.tgrid(dtbnds[0, 0], dtbnds[-1, 1], intvl='yrly')
lat = d1.variables['lat'][:]
lon = d1.variables['lon'][:]
latv = np.transpose(d1.variables['lat_vertices'][:], (2, 0, 1))
lonv = np.transpose(d1.variables['lon_vertices'][:], (2, 0, 1))


v1 = d1.variables[type1][:]
t0ann = mcmath.mth_ann_mean(v1)

stdname = d1.variables[type1].standard_name
longname = d1.variables[type1].long_name
v1_units = d1.variables[type1].units
v1_cellmeth = d1.variables[type1].cell_methods
if type1 in nocellmeas:
	pass
else:
	v1_cellmeas = d1.variables[type1].cell_measures
v1_coord = d1.variables[type1].coordinates

d1.close()

dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
dcur1.createDimension('j', lat.shape[0])
dcur1.createDimension('i', lat.shape[1])
dcur1.createDimension('time', None)
dcur1.createDimension('bnds', 2)
dcur1.createDimension('vertices', 4)

dcur1.history = 'created by script: %s' % scriptname
dcur1.processed_file = '%s' % files1[0]

time_var = dcur1.createVariable('time', 'd', ('time',))
time_var.long_name = 'time'
time_var.standard_name = 'time'
time_var.units = 'days since 0001-01-01 00:00:00'
time_var.bounds = 'time_bnds'
time_var.calendar = 'proleptic_gregorian'
time_var.axis = 'T'
time_var[:] = d2n(tax)

timebnd_var = dcur1.createVariable('time_bnds', 'd', ('time', 'bnds'))
timebnd_var[:] = d2n(taxbnds)

lat_var = dcur1.createVariable('lat', 'd', ('j', 'i'))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var.bounds = 'lat_vertices'
lat_var[:] = lat

lon_var = dcur1.createVariable('lon', 'd', ('j', 'i'))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var.bounds = 'lon_vertices'
lon_var[:] = lon

latbnd_var = dcur1.createVariable('lat_vertices', 'd', ('vertices', 'j', 'i'))
latbnd_var.units = 'degrees_north'
latbnd_var[:] = latv

lonbnd_var = dcur1.createVariable('lon_vertices', 'd', ('vertices', 'j', 'i'))
lonbnd_var.units = 'degrees_east'
lonbnd_var[:] = lonv

var1_var = dcur1.createVariable(type1, 'f', ('time', 'j', 'i'), fill_value=-1e34)
var1_var.long_name = longname
var1_var.standard_name = stdname
var1_var.units = v1_units
var1_var.cell_methods = v1_cellmeth
if type1 in nocellmeas:
	pass
else:
	var1_var.cell_measures = v1_cellmeas
var1_var.coordinates = v1_coord
var1_var.missing_value = np.float32(-1e34)

t0ann.data[t0ann.mask] = -1e34
var1_var[:] = t0ann[:].copy()

dcur1.sync()
dcur1.close()

if flen == 1:
	print "\n\nDONE\n\n"
	exit()

## The rest of the files, if more than one

for i in xrange(1, flen):
	d1 = nc4.Dataset(files1[i])

	if (omon_re.match(files1[i]) is None) and (oimon_re.match(files1[i]) is None):
		print "\nUnsupported datafile type for file: \'%s\'\n\n" % files1[i]
		continue

	if omon_re.match(files1[i]) is not None:
		type1 = omon_re.match(files1[i]).groups()[0]
		fnpart1 = omon_re.match(files1[i]).groups()[1]
	else:
		type1 = oimon_re.match(files1[i]).groups()[0]
		fnpart1 = oimon_re.match(files1[i]).groups()[1]

	nfname = type1 + "_ann_" + fnpart1

	print nfname
	t1 = d1.variables['time'][:]
	dt1 = n2d(t1, units=d1.variables['time'].units)
	tbnds = d1.variables['time_bnds'][:]
	dtbnds = n2d(tbnds, units=d1.variables['time'].units)
	tax, taxbnds = mcmath.tgrid(dtbnds[0, 0], dtbnds[-1, 1], intvl='yrly')

	lat = d1.variables['lat'][:]
	lon = d1.variables['lon'][:]
	latv = np.transpose(d1.variables['lat_vertices'][:], (2, 0, 1))
	lonv = np.transpose(d1.variables['lon_vertices'][:], (2, 0, 1))

	v1 = d1.variables[type1][:]
	t0ann = mcmath.mth_ann_mean(v1)

	stdname = d1.variables[type1].standard_name
	longname = d1.variables[type1].long_name
	v1_units = d1.variables[type1].units
	v1_cellmeth = d1.variables[type1].cell_methods
	if type1 in nocellmeas:
		pass
	else:
		v1_cellmeas = d1.variables[type1].cell_measures
	v1_coord = d1.variables[type1].coordinates
	
	d1.close()

	dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
	dcur1.createDimension('j', lat.shape[0])
	dcur1.createDimension('i', lat.shape[1])
	dcur1.createDimension('time', None)
	dcur1.createDimension('bnds', 2)
	dcur1.createDimension('vertices', 4)

	dcur1.history = 'created by script: %s' % scriptname
	dcur1.processed_file = '%s' % files1[i]

	time_var = dcur1.createVariable('time', 'd', ('time',))
	time_var.long_name = 'time'
	time_var.standard_name = 'time'
	time_var.units = 'days since 0001-01-01 00:00:00'
	time_var.bounds = 'time_bnds'
	time_var.calendar = 'proleptic_gregorian'
	time_var.axis = 'T'
	time_var[:] = d2n(tax)

	timebnd_var = dcur1.createVariable('time_bnds', 'd', ('time', 'bnds'))
	timebnd_var[:] = d2n(taxbnds)

	lat_var = dcur1.createVariable('lat', 'd', ('j', 'i'))
	lat_var.standard_name = 'latitude'
	lat_var.long_name = "latitude coordinate"
	lat_var.units = 'degrees_north'
	lat_var.axis = 'Y'
	lat_var.bounds = 'lat_vertices'
	lat_var[:] = lat

	lon_var = dcur1.createVariable('lon', 'd', ('j', 'i'))
	lon_var.standard_name = 'longitude'
	lon_var.long_name = "longitude coordinate"
	lon_var.units = 'degrees_east'
	lon_var.axis = 'X'
	lon_var.bounds = 'lon_vertices'
	lon_var[:] = lon

	latbnd_var = dcur1.createVariable('lat_vertices', 'd', ('vertices', 'j', 'i'))
	latbnd_var.units = 'degrees_north'
	latbnd_var[:] = latv

	lonbnd_var = dcur1.createVariable('lon_vertices', 'd', ('vertices', 'j', 'i'))
	lonbnd_var.units = 'degrees_east'
	lonbnd_var[:] = lonv

	var1_var = dcur1.createVariable(type1, 'f', ('time', 'j', 'i'), fill_value=-1e34)
	var1_var.long_name = longname
	var1_var.standard_name = stdname
	var1_var.units = v1_units
	var1_var.cell_methods = v1_cellmeth
	if type1 in nocellmeas:
		pass
	else:
		var1_var.cell_measures = v1_cellmeas
	var1_var.coordinates = v1_coord
	var1_var.missing_value = np.float32(-1e34)

	t0ann.data[t0ann.mask] = -1e34
	var1_var[:] = t0ann[:].copy()

	dcur1.sync()
	dcur1.close()

print "\n\nDONE\n\n"
