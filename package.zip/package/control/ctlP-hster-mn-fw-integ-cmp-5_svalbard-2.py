from matplotlib import font_manager
prop1 = font_manager.FontProperties(size=9)
prop2 = font_manager.FontProperties(size=8)

d1 = use('ctl-hsteric-ssh-zmn.nc')
lonv1 = d1.v['lon_vertices'][:]
latv1 = d1.v['lat_vertices'][:]
lon = d1.v['lon'][:]
lat = d1.v['lat'][:]
tax = d1.dt_vals('ssh')
tax999 = tax[1:]
tax3 = tax
tax111 = tax[55:-55]

xax = lonv1
yax = latv1

hster = d1.v['ssh'][:,:85]
hster_dt = mcmath.my_dtrnd(hster,arange(tax.size,dtype=np.float32),0)

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

darea = use('../areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')

dvol = use('../volcello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
vol = dvol.v['volcello'][:]


#~ bnds = (arange(12)).tolist()
#~ norm = mpl.colors.BoundaryNorm(bnds,256)
#~ pcolormesh(bas,norm=norm)



ao_msk1 = amsk[:85]
area1 = area[:85]
ao_area = ao_msk1*area1
ao_vol = vol[:,:85,:]*ao_msk1.reshape(1,85,256)
ao_totvol = ao_vol.sum()


###### Hster boxcar running mean

hstermn = (hster_dt*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1) / ao_area.sum()

#mcp.dateplt1(tax,hstermn,yl=100,nomth=True)


hster_lf_111 = mcmath.rm_calc(hster_dt,'b',111,1)[1]
tax1 = tax[55:-55]

#hster111mn = (hster_lf_111*ao_area.reshape(1,220,256)).sum(axis=1).sum(axis=1) / ao_area.sum()

#~ hster111 = hster111mn
#~ hster1 = hster111 / hster111.std()
#~ hster1 = hster1 - hster1.mean()


##

soarcmn = load('ctlP_so_svalbardmn.npy')
fwtot = ((34.66 - soarcmn)/34.66)*ao_totvol
fwdiff = (fwtot[1:] - fwtot[:-1]) / 31557600.0
fwdt = mcmath.my_dtrnd(fwdiff,tax[1:])
fwdiff111 = mcmath.run_mean_win_mskd(fwdt,sp.signal.boxcar(111))[1]
fwdiff111dt = mcmath.my_dtrnd(fwdiff111,tax1[1:])

soam = soarcmn - soarcmn.mean()
soam = mcmath.my_dtrnd(soam,tax)
soamnorm = soam*-1 / soam.std(ddof=1)

#~ saltarcsum = load('salt_svalsum-1.npy')
#~ saas = saltarcsum - saltarcsum.mean()
#~ saasnorm = saas*-1 / saas.std(ddof=1)

###### WFO boxcar running mean

d1 = nc4.MFDataset('wfo/wfo_ann_MPI-ESM-P_*.nc')
t1 = d1.variables['time'][:]
dt1 = n2d(t1)

wfo = d1.variables['wfo'][:,:85]
wfoarc = wfo* 0.001 * ao_area.reshape(1,85,256)
wfof = wfoarc.sum(axis=1).sum(axis=1)
wfodt = mcmath.my_dtrnd(wfof,tax)
wfof111 = mcmath.run_mean_win_mskd(wfodt,sp.signal.boxcar(111))[1]
wfof111dt = mcmath.my_dtrnd(wfof111,tax111)

dflux1 = nc4.Dataset('fwflux_arc_5_svalbard-P.nc')
fwflux1 = dflux1.variables['fwflux'][:]
iceflux1 = dflux1.variables['iceflux'][:] * (30./35.)

dflux2 = nc4.Dataset('fwflux_arc_5_canarc-P.nc')
fwflux2 = dflux2.variables['fwflux'][:]
iceflux2 = dflux2.variables['iceflux'][:] * (30./35.)

fwflux = np.r_[fwflux1,fwflux2[1:],fwflux2[0].reshape(1,tax3.size,40,3)]
fwmask = np.r_[fwflux1.mask,fwflux2[1:].mask,fwflux2[0].mask.reshape(1,tax3.size,40,3)]
fwflux.mask = fwmask

iceflux = np.r_[iceflux1,iceflux2[1:],iceflux2[0].reshape(1,tax3.size,3)]
icemask = np.r_[iceflux1.mask,iceflux2[1:].mask,iceflux2[0].mask.reshape(1,tax3.size,3)]
iceflux.mask = icemask

its = iceflux.sum(axis=0).sum(axis=1) / 1000.
itsdt = mcmath.my_dtrnd(its,tax)
fwts = fwflux.sum(axis=0).sum(axis=1).sum(axis=1)
fwvoldt = mcmath.my_dtrnd(fwts,tax)
fwts111 = mcmath.run_mean_win_mskd(fwvoldt,sp.signal.boxcar(111))[1]
fwts111dt = mcmath.my_dtrnd(fwts111,tax111)

d1 = nc4.MFDataset('../ice/control/sit_ann_MPI-ESM-P_*.nc')
sit1 = d1.variables['sit'][:,:85]
sitsum = (sit1*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1)
sitsuma = sitsum - sitsum.mean()
sitdiff = (sitsum[1:] - sitsum[:-1])/31557600.0
sd1 = sitdiff  * (30./35.)
sd1dt = mcmath.my_dtrnd(sd1,tax[1:])

dsim = nc4.MFDataset('../ice/control/sim_ann_MPI-ESM-P_*.nc')
sim1 = dsim.variables['sim'][:,:85]
sim_tot = sim1*ao_area.reshape(1,85,256)
simsum = (sim1*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1)
simsuma = simsum - simsum.mean()
simdiff = (simsum[1:] - simsum[:-1])/31557600.0
simd1 = (simdiff / 1000.) * (30./35.)
simd1dt = mcmath.my_dtrnd(simd1,tax[1:])

#~ dsfdsi = nc4.Dataset('sfdsi_ann.nc')
#~ sfdsi = dsfdsi.variables['sfdsi'][:,:85]
#~ sfdsisum = (sfdsi*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1)
#~ fwflux_sfdsi = (sfdsisum/35.0)
#~ fwsfdsidt = mcmath.my_dtrnd(fwflux_sfdsi,tax)
#~ fwflux_sfdsi111 = mcmath.run_mean_win_mskd(fwsfdsidt,sp.signal.boxcar(111))[1]

dprsn = nc4.MFDataset('prsn/prsn_ann*.nc')
prsn1 = dprsn.variables['prsn'][:,:85]
prsn_tot = prsn1*ao_area.reshape(1,85,256)*31557600.0
prsnsum = (prsn1*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1)
prsnint = prsnsum * 31557600.0
prsnint111 = mcmath.run_mean_win_mskd(prsnint,sp.signal.boxcar(111))[1]

sim_ms_tot = sim_tot - prsn_tot
sim_ms_sum = sim_ms_tot.sum(axis=1).sum(axis=1)
simmssumdiff = (sim_ms_sum[1:] - sim_ms_sum[:-1])/31557600.0
simmssumd1 = (simmssumdiff / 1000.) * (30./35.)
simmdt = mcmath.my_dtrnd(simmssumd1,tax[1:])

#~ net = wfof111 + fwts111
#~ net_a = net / net.std()
#~ net_a = net - net.mean()

net1 = wfodt + fwvoldt
ncs1 = (net1 - net1.mean()).cumsum()
ncs1anom = ncs1 - ncs1.mean()
ncs1norm = ncs1anom / ncs1anom.std(ddof=1)
net1_111 = mcmath.run_mean_win_mskd(net1,sp.signal.boxcar(111))[1]
net1_111dt = mcmath.my_dtrnd(net1_111,tax111)
net1_dt = mcmath.my_dtrnd(net1,tax)
ncs1normdt = mcmath.my_dtrnd(ncs1norm,tax)

##  detrended variable names
# fwdt  soam  wfodt  itsdt  fwvoldt  sd1dt  simd1dt
# fwsfdsidt  simmdt


net2 = wfodt + fwvoldt + itsdt
ncs2 = (net2 - net2.mean()).cumsum()
ncs2anom = ncs2 - ncs2.mean()
ncs2norm = ncs2anom / ncs2anom.std(ddof=1)
net2_111 = mcmath.run_mean_win_mskd(net2,sp.signal.boxcar(111))[1]
net2_111dt = mcmath.my_dtrnd(net2_111,tax111)
ncs2normdt = mcmath.my_dtrnd(ncs2norm,tax)

#~ net3 = wfodt + fwvoldt - fwsfdsidt
#~ 
#~ ncs3 = (net3 - net3.mean()).cumsum()
#~ ncs3anom = ncs3 - ncs3.mean()
#~ ncs3norm = ncs3anom / ncs3anom.std(ddof=1)
#~ net3_111 = mcmath.run_mean_win_mskd(net3,sp.signal.boxcar(111))[1]
#~ net3_111dt = mcmath.my_dtrnd(net3_111,tax111)
#~ ncs3normdt = mcmath.my_dtrnd(ncs3norm,tax)

#~ net4 = wfodt[1:] + fwvoldt[1:] + itsdt[1:] - sd1dt
#~ ncs4 = (net4 - net4.mean()).cumsum()
#~ ncs4anom = ncs4 - ncs4.mean()
#~ ncs4norm = ncs4anom / ncs4anom.std(ddof=1)
#net4_111 = mcmath.run_mean_win_mskd(net4,sp.signal.boxcar(111))[1]

net5 = wfodt[1:] + fwvoldt[1:] + itsdt[1:] - simd1dt
ncs5 = (net5 - net5.mean()).cumsum()
ncs5anom = ncs5 - ncs5.mean()
ncs5norm = ncs5anom / ncs5anom.std(ddof=1)
net5_111 = mcmath.run_mean_win_mskd(net5,sp.signal.boxcar(111))[1]

net6 = wfodt[1:] + fwvoldt[1:] + itsdt[1:] - simmdt
i_s = itsdt[1:] - simmdt
ncs6 = (net6 - net6.mean()).cumsum()
ncs6anom = ncs6 - ncs6.mean()
ncs6norm = ncs6anom / ncs6anom.std(ddof=1)
#net6_111 = mcmath.run_mean_win_mskd(net6,sp.signal.boxcar(111))[1]
i_s111 = mcmath.run_mean_win_mskd(i_s,sp.signal.boxcar(111))[1]
i_s111dt = mcmath.my_dtrnd(i_s111,tax111[1:])
i_sdt = mcmath.my_dtrnd(i_s,tax999)

ncs6normdt = mcmath.my_dtrnd(ncs6norm,tax999)
net6_111 = mcmath.run_mean_win_mskd(net6,sp.signal.boxcar(111))[1]
net6_111dt = mcmath.my_dtrnd(net6_111,tax111[1:])
net6_dt = mcmath.my_dtrnd(net6,tax999)

d2 =  nc4.MFDataset('zos/zos_ann_MPI-ESM-P_*.nc')

ssh = d2.variables['zos'][:,:85]

ssh_dt = mcmath.my_dtrnd(ssh,arange(tax.size,dtype=np.float32))

#~ ssh_lf_111 = mcmath.rm_calc(ssh_dt,'b',111,1)[1]
#~ 
#~ ssh_111mn = (ssh_lf_111*ao_area.reshape(1,85,256)).sum(axis=1).sum(axis=1) / ao_area.sum()


hstermnnorm = hstermn / hstermn.std(ddof=1)
hstermnnormdt = mcmath.my_dtrnd(hstermnnorm,tax)

######
corr2 = corrcoef(hstermnnormdt,ncs2normdt)[0][1]
corr3 = corrcoef(hstermnnormdt,ncs1normdt)[0][1]
label2 = 'Net fw integral w/ ice berg\ntransport (%.2f)' % corr2
label3 = 'Net fw integral, no ice corrections (%.2f)' % corr3

mcp.dateplt1(tax,hstermnnorm,yl=100,nomth=True,label='Halosteric')
mcp.dateplt_m(tax,ncs2norm,yl=100,nomth=True,label=label2)
mcp.dateplt_m(tax,ncs1norm,yl=100,nomth=True,label=label3)

legend(loc=2,prop=prop1)
title('Halosteric SSH mean vs. Net FW flux cum. sum (normalized)',size=11)
#savefig('halomean-netfwcumsum-cmp-1.png',dpi=200)
##

mcp.dateplt1(tax,hstermnnorm,yl=100,nomth=True,label='Halosteric')
mcp.dateplt_m(tax,ncs2norm,yl=100,nomth=True,label='Net w/ ice berg\ntransport')
legend(loc=2,prop=prop1)
title('Halosteric SSH mean vs. Net FW flux cum. sum (normalized)',size=11)
#savefig('halomean-netfwcumsum-cmp-2.png',dpi=200)

#~ mcp.dateplt1(tax,hstermnnorm,yl=100,nomth=True,label='Halosteric')
#~ mcp.dateplt_m(tax3,ncs3norm,yl=100,nomth=True,label='Net w/ ice salt flux')
#~ legend(loc=2,prop=prop1)
#~ title('Halosteric SSH mean vs. Net FW flux cum. sum (normalized)',size=11)
#~ #savefig('halomean-netfwcumsum-cmp-3.png',dpi=200)

mcp.dateplt1(tax,soamnorm,yl=100,nomth=True,label='Salinity, Arctic mean')
mcp.dateplt_m(tax999,ncs6norm,yl=100,nomth=True,label='Net w/ delt sim (minus snow)')
legend(loc=2,prop=prop1)
title('Salinity Arctic mean vs. Net FW flux cum. sum (normalized)',size=11)
#savefig('somean-netfwcumsum-cmp-1.png',dpi=200)

#~ mcp.dateplt1(tax,hstermnnorm,yl=100,nomth=True,label='Halosteric')
#~ mcp.dateplt_m(tax,soamnorm,yl=100,nomth=True,label='Salinity, Arctic mean')
#~ mcp.dateplt_m(tax,saasnorm,yl=100,nomth=True,label='Salt, Arctic sum')
#~ 
#~ legend(loc=2,prop=prop1)
#~ title('Halosteric SSH mean vs. Arctic salinity mean and salt sum (normalized)',size=11)
#~ #savefig('halomean-sa-so-mn-cmp-1.png',dpi=200)

#~ mcp.dateplt1(tax999,fwdiff,label='freshwater change rate in Arctic',yl=100,nomth=True)
#~ mcp.dateplt_m(tax,wfof,label='external water flux into Arctic O.',yl=100,nomth=True)
#~ mcp.dateplt_m(tax,fwts,label='oceanic fw flux into Arctic O.',yl=100,nomth=True)
#~ mcp.dateplt_m(tax,fwflux_sfdsi,label='surface ice salt flux (into ocean)',yl=100,nomth=True)
#~ mcp.dateplt_m(tax,net3,label='net flux with surface ice salt flux',yl=100,nomth=True)
#~ 
#~ legend(loc=2,prop=prop1)
#~ ylabel('FW flux into Arctic Ocean (m$^{3}$ s$^{-1}$)')
#~ 
#~ ax4 = plt.gca()
#~ ax4.axhline(0.,color='k')
#~ #savefig('fw-component-cmp-1_annual.png',dpi=200)
#~ 
#~ meandiff = fwdiff.mean() - net3.mean()
#~ resids = fwdiff - net3[1:]
#~ 
#~ print "mean difference bet. fw content and component sum: %.2f\n\n" % meandiff
#~ 
#~ print "std dev bet. fw content and component sum: %.2f\n\n" % resids.std()


mcp.dateplt1(tax111[1:],fwdiff111,label='freshwater change rate in Arctic',yl=100,nomth=True)
mcp.dateplt_m(tax111,wfof111,label='external water flux into Arctic O.',yl=100,nomth=True)
mcp.dateplt_m(tax111,fwts111,label='oceanic fw flux into Arctic O.',yl=100,nomth=True)
mcp.dateplt_m(tax111,net1_111,label='net fw flux w/o ice into Arctic O.',yl=100,nomth=True)
#~ mcp.dateplt_m(tax111,-1*fwflux_sfdsi111,label='surface ice salt flux (out of ocean)',yl=100,nomth=True)
#~ mcp.dateplt_m(tax111,net3_111,label='net flux with surface ice salt flux',yl=100,nomth=True)
mcp.dateplt_m(tax111[1:],net5_111,label='net flux with ice trans and d/dt sim',yl=100,nomth=True)
mcp.dateplt_m(tax111[1:],i_s111,label='freshwater flux, via ice, into Arctic',yl=100,nomth=True)


legend(loc=(0.02,0.63),prop=prop1)
ylabel('FW flux (111-yr smthd) into Arctic Ocean (m$^{3}$ s$^{-1}$)')

ax4 = plt.gca()
ax4.axhline(0.,color='k')
#savefig('fw-component-cmp-2_111yr.png',dpi=200)


#~ meandiff111 = fwdiff111.mean() - net3_111.mean()
#~ resids111 = fwdiff111 - net3_111[1:]
#~ 
#~ print "mean difference bet. fw content and component sum: %.2f\n\n" % meandiff111
#~ 
#~ print "std dev bet. fw content and component sum: %.2f\n\n" % resids111.std()

######
mcp.dateplt1(tax111[1:],fwdiff111,label='freshwater change rate in Arctic',yl=100,nomth=True)
mcp.dateplt_m(tax111,net1_111,label='net fw flux w/o ice into Arctic O.',yl=100,nomth=True)
#~ mcp.dateplt_m(tax111,-1*fwflux_sfdsi111,label='surface ice salt flux (out of ocean)',yl=100,nomth=True)
#~ mcp.dateplt_m(tax111,net3_111,label='net flux with surface ice salt flux',yl=100,nomth=True)
mcp.dateplt_m(tax111[1:],net5_111,label='net flux with ice trans and d/dt sim',yl=100,nomth=True)
mcp.dateplt_m(tax111[1:],i_s111,label='freshwater flux, via ice, into Arctic',yl=100,nomth=True)


legend(loc=2,prop=prop1)
ylabel('FW flux (111-yr smthd) into Arctic Ocean (m$^{3}$ s$^{-1}$)')
#savefig('fw-component-cmp-3_111.png',dpi=200)
##


######
corr2 = corrcoef(hstermnnormdt,ncs2normdt)[0][1]
corr3 = corrcoef(hstermnnormdt[1:],ncs6normdt)[0][1]
label2 = 'Net fw w/ ice berg\ntransport (%.2f)' % corr2
label3 = 'Net fw w/ ice berg\ntransport and d/dt net ice\nthickness (%.2f)' % corr3

mcp.dateplt1(tax,hstermnnormdt,yl=100,nomth=True,ls='-',marker=None,label='Halosteric')
mcp.dateplt_m(tax,ncs2normdt,yl=100,nomth=True,ls='-',marker=None,label=label2)
mcp.dateplt_m(tax999,ncs6normdt,yl=100,nomth=True,ls='-',marker=None,label=label3)
#mcp.dateplt_m(tax,ncs1norm,yl=100,nomth=True,label='Net w/o ice')

legend(loc=2,prop=prop1)
title('Halosteric SSH Arctic mean vs. Net FW flux cum. sum (normalized)',size=11)
#savefig('halomean-netfwcumsum-cmp-4.png',dpi=200)
##


######
corr2 = corrcoef(fwdiff111,wfof111[1:])[0][1]
corr3 = corrcoef(fwdiff111,fwts111[1:])[0][1]
corr4 = corrcoef(fwdiff111,i_s111)[0][1]
corr5 = corrcoef(fwdiff111,net1_111[1:])[0][1]
corr6 = corrcoef(fwdiff111,net6_111)[0][1]
label2 = 'external water flux into Arctic O. (%.2f)' % corr2
label3 = 'oceanic fw flux into Arctic O. (%.2f)' % corr3
label4 = 'freshwater flux, via ice, into Arctic (%.2f)' % corr4
label5 = 'net fw flux w/o ice into Arctic O. (%.2f)' % corr5
label6 = 'net flux with ice trans and d/dt sim (%.2f)' % corr6

mcp.dateplt1(tax111[1:],fwdiff111/1.e3,label='freshwater change rate in Arctic',yl=100,nomth=True,ls='--',marker=None,color='black',lw=3)
mcp.dateplt_m(tax111,wfof111/1.e3,label=label2,yl=100,nomth=True,ls='-',marker=None,color='orange',lw=3)
mcp.dateplt_m(tax111,fwts111/1.e3,label=label3,yl=100,nomth=True,ls='-',marker=None,color='firebrick',lw=3)
mcp.dateplt_m(tax111[1:],i_s111/1.e3,label=label4,yl=100,nomth=True,ls='-',marker=None,color='olive',lw=3)
mcp.dateplt_m(tax111,net1_111/1.e3,label=label5,yl=100,nomth=True,ls='-',marker=None,color='blue',lw=3)
mcp.dateplt_m(tax111[1:],net5_111/1.e3,label=label6,yl=100,nomth=True,ls='--',marker=None,color='cyan',lw=3)


legend(loc=(0.02,0.68),prop=prop1)
ylabel('FW flux (111-yr smthd) into Arctic Ocean ($mSv$)',size=13,va='center')

ax4 = plt.gca()
ax4.axhline(0.,color='k')
title('Freshwater flux into Arctic Ocean by components',size=13)
#savefig('fw-component-cmp-4_111yr-2.png',dpi=200)

##


yrlen = 10
intvlen = 5
ilen = (tax3.size - yrlen)/intvlen +1

corr_fw_net1 = np.zeros(ilen)
for i in arange(ilen):
    corr_fw_net1[i] = corrcoef(fwdt[i*intvlen:(i*intvlen)+yrlen],net1[:-1][i*intvlen:(i*intvlen)+yrlen])[0,1]

corr_fw_net6 = np.zeros(ilen)
for i in arange(ilen):
    corr_fw_net6[i] = corrcoef(fwdt[i*intvlen:(i*intvlen)+yrlen],net6[i*intvlen:(i*intvlen)+yrlen])[0,1]

dtnew = dt1[arange(0,tax3.size-yrlen+1,intvlen)+yrlen/2]

figure(); plot(dtnew,corr_fw_net6)

corr_hster_net1 = np.zeros(ilen)
for i in arange(ilen):
    corr_hster_net1[i] = corrcoef(hstermnnorm[i*intvlen:(i*intvlen)+yrlen],ncs1[i*intvlen:(i*intvlen)+yrlen])[0,1]

corr_hster_net6 = np.zeros(ilen)
for i in arange(ilen):
    corr_hster_net6[i] = corrcoef(hstermnnorm[1:][i*intvlen:(i*intvlen)+yrlen],ncs6[i*intvlen:(i*intvlen)+yrlen])[0,1]

### correlations

corrcoef(hstermnnormdt,ncs2normdt)
#~ corrcoef(hstermnnormdt,ncs3normdt)
#corrcoef(hstermnnormdt[1:],ncs4)
corrcoef(hstermnnormdt[1:],ncs5)
corrcoef(hstermnnormdt[1:],ncs6normdt)



