import mcmath
import numpy as np
import scipy as sp
from matplotlib import pyplot as plt

f2 = open('pmip_forcing/PMIP_LM_radforc.txt')
forc1 = f2.readlines()

#  Well-mixed GHGs (baseline 850 CE)
#   WMGHG  (CO2, CH4 and N2O combined)
wmghg1 = forc1[19:1019]

#   Volcanic forcing (absolute W/m2)
#   GRA             CEA
volc1 = forc1[1174:2174]

#   Solar TSI forcing (baseline PMOD 1976-2006)
#   DB_(noback) DB_(back) MEA_(noback) MEA_(back)  SBF    VSK
sol1 = forc1[2329:3329]

#   Land use/Land Cover change (to 1992) (baseline pristine conditions)
land1 = forc1[3482:4493]

wmghg1a = np.zeros(1000)
vgra1a = np.zeros(1000)
vcea1a = np.zeros(1000)
sdbn1a = np.zeros(1000)
sdbb1a = np.zeros(1000)
smen1a = np.zeros(1000)
smeb1a = np.zeros(1000)
ssbf1a = np.zeros(1000)
svsk1a = np.zeros(1000)
tghg1a = np.zeros(1000)
tvolc1a = np.zeros(1000)
tsol1a = np.zeros(1000)

for i in xrange(len(wmghg1)):
    line1w = wmghg1[i]
    line1v = volc1[i]
    line1s = sol1[i]
    tghg1a[i], wmghg1a[i] = np.float32(line1w.split())
    tvolc1a[i], vgra1a[i], vcea1a[i] = np.float32(line1v.split())
    tsol1a[i], sdbn1a[i], sdbb1a[i], smen1a[i], smeb1a[i], ssbf1a[i], svsk1a[i] = np.float32(line1s.split())

land1a = np.zeros(1000)
tland1a = np.zeros(1000)
j = 0

for i in xrange(len(land1)):
    line1 = np.float32(land1[i].split())
    if i == 0:
        tland1a[j], land1a[j] = line1
        j = j + 1
        continue
    if line1[0] != tland1a[j - 1]:
        tland1a[j], land1a[j] = line1
        j = j + 1

solmean1 = (sdbn1a + sdbb1a + smen1a + smeb1a + ssbf1a + svsk1a) / 6.

win1 = sp.signal.hamming(21)

wmghg1a_sm2 = mcmath.run_mean_win_mskd2(wmghg1a, win=win1)[1]
land1a_sm2 = mcmath.run_mean_win_mskd2(land1a, win=win1)[1]
volc_cea_sm2 = mcmath.run_mean_win_mskd2(vcea1a, win=win1)[1]
volc_gra_sm2 = mcmath.run_mean_win_mskd2(vgra1a, win=win1)[1]
smean1_sm2 = mcmath.run_mean_win_mskd2(solmean1, win=win1)[1]

t2 = np.arange(860, 1840)

plt.figure()
plt.plot(t2, volc_gra_sm2, label='volcanic GRA', c='red')
plt.plot(t2, volc_cea_sm2, label='volcanic CEA', color='orange')
plt.plot(t2, wmghg1a_sm2, label='well-mixed GHGs', c='blue')
plt.plot(t2, smean1_sm2, label='solar', c='green')
plt.plot(t2, land1a_sm2, label='land use', c='cyan')

plt.legend(loc=3)

plt.ylabel('W m$^{-2}$')
plt.title('Forcing components for past1000 experiment')
ax1 = plt.gca()
ax1.set_xticks(np.arange(850, 1851, 200))
ax1.axhline(0.0, color='k', lw=0.5)

plt.savefig('fig1_forcings-2.png',dpi=300)
