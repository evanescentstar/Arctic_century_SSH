from ferr import use
import netCDF4 as nc4
import numpy as np

scriptname = 'hster-zavg-3.py'
fname = 'hsteric-heights-3.nc'
d1 = use(fname)

t1 = d1.d['time'][:]
tbnds1 = d1.d['time_bnds'][:]
lat = d1.v['lat'][:]
lon = d1.v['lon'][:]
latv = d1.v['lat_vertices'][:]
lonv = d1.v['lon_vertices'][:]




ssh_da = np.ma.masked_all((1000,220,256),dtype=np.float32)
ii = 0

for l in xrange(1000):
	if ii % 10 == 0:
		print '\nat %dth time step\n' % ii
	ssh_da[l] = (d1.v['ssh'][l]).sum(axis=0)
	ii = ii + 1

outfile = 'hsteric-ssh-zmn-3.nc'

dcur1 = nc4.Dataset(outfile,'w')
dcur1.createDimension('time',None)
dcur1.createDimension('j',lat.shape[0])
dcur1.createDimension('i',lat.shape[1])
dcur1.createDimension('bnds',2)
dcur1.createDimension('vertices',4)

dcur1.history = 'created by script: %s' % scriptname
dcur1.processed_file = '%s' % fname


time_var = dcur1.createVariable('time','d',('time',))
time_var.long_name = 'time'
time_var.standard_name = 'time'
time_var.units = 'days since 0001-01-01 00:00:00'
time_var.bounds = 'time_bnds'
time_var.calendar = 'proleptic_gregorian'
time_var.axis= 'T'
time_var[:] = t1

timebnd_var = dcur1.createVariable('time_bnds','d',('time','bnds'))
timebnd_var[:] = tbnds1

lat_var = dcur1.createVariable('lat','d',('j','i'))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var.bounds = 'lat_vertices'
lat_var[:] = lat

lon_var = dcur1.createVariable('lon','d',('j','i'))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var.bounds = 'lon_vertices'
lon_var[:] = lon

latbnd_var = dcur1.createVariable('lat_vertices','d',('vertices','j','i'))
latbnd_var.units = 'degrees_north'
latbnd_var[:] = latv

lonbnd_var = dcur1.createVariable('lon_vertices','d',('vertices','j','i'))
lonbnd_var.units = 'degrees_east'
lonbnd_var[:] = lonv


h_var = dcur1.createVariable('ssh','f',('time','j','i'),fill_value=-1e34)
h_var.long_name = 'halosteric delta ssh, depth summed, yearly average'
h_var.units = 'm'
h_var.missing_value = np.float32(-1e34)
h_var[:] = ssh_da


dcur1.sync()
dcur1.close()

