import mcmath
import mcp
from ferr import use
import netCDF4 as nc4
from datetime import datetime as dt
import numpy as np
from matplotlib import font_manager
from matplotlib import pyplot as plt

prop1 = font_manager.FontProperties(size=9)

j1 = 44
i1 = 226

d1 = use('hsteric-ssh-zmn-3.nc')
lonv1 = d1.v['lon_vertices'][:]
latv1 = d1.v['lat_vertices'][:]
lon = d1.v['lon'][:]
lat = d1.v['lat'][:]
tax = d1.dt_vals('ssh')

xax = lonv1
yax = latv1

zos = d1.v['ssh'][:]  # from d1, forced
zos_dt = mcmath.my_dtrnd(zos, np.arange(1000.))  # from d1, forced

## control lr
d3 = use('control/ctl-hsteric-ssh-zmn.nc')
tax3 = d3.dt_vals('ssh')

zos3 = d3.v['ssh'][:]
zos3_dt = mcmath.my_dtrnd(zos3, np.arange(tax3.size))

dbas = use('basin_fx_MPI-ESM-P_past1000_r0i0p0.nc')
bas = dbas.gv('basin')

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]
# ~ bnds = (arange(12)).tolist()
# ~ norm = mpl.colors.BoundaryNorm(bnds,256)
# ~ pcolormesh(bas,norm=norm)


ao_msk = amsk
ao_area = ao_msk * area
awgt = ao_area / ao_area.max()
awgt1 = np.sqrt(awgt)

zaomn = (zos * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()  ## from d1, forced

zao3mn = (zos3 * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

zos_lf_11 = mcmath.rm_calc(zos_dt, 'h', 11, 1)[1]  ## from d1, forced
tax1 = tax[5:-5]

zao11mn = (zos_lf_11 * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()  ## from d1, forced

zos3_lf_11 = mcmath.rm_calc(zos3_dt, 'h', 11, 1)[1]
tax3a = tax3[5:-5]

zao311mn = (zos3_lf_11 * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

d2 = nc4.MFDataset('zos/zos_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')  ## from d2, forced
zos2 = d2.variables['zos'][:]
zos2_dt = mcmath.my_dtrnd(zos2, np.arange(1000.))
zos2_lf_11 = mcmath.rm_calc(zos2_dt, 'h', 11, 1)[1]
zao2_11mn = (zos2_lf_11 * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

d4 = nc4.MFDataset('control/zos/zos_ann_MPI-ESM*.nc')
zos4 = d4.variables['zos'][:]
zos4_dt = mcmath.my_dtrnd(zos4, np.arange(tax3.size))
zos4_lf_11 = mcmath.rm_calc(zos4_dt, 'h', 11, 1)[1]
zao4_11mn = (zos4_lf_11 * ao_area.reshape(1, 220, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

fw1 = np.load('fwtot_forced.npy')
fw1_11 = mcmath.rm_calc(fw1, 'h', 11, 1)[1] - fw1.mean()

fw2 = np.load('fwtot_control.npy')
fw2_11 = (mcmath.rm_calc(fw2, 'h', 11, 1)[1] - fw2.mean())[:990]

fwht1 = np.load('fwht_forced.npy')
fwht1spot = fwht1[:, j1, i1]
fwht1spot_11 = mcmath.rm_calc(fwht1spot, 'h', 11, 1)[1] - fwht1spot.mean()

fwht2 = np.load('fwht_control.npy')
fwht2spot = fwht2[:, j1 - 30, i1]
fwht2spot_11 = (mcmath.rm_calc(fwht2spot, 'h', 11, 1)[1] - fwht2spot.mean())[:990]

#######plotting
fig = plt.figure(figsize=(8, 4.5))

# text placements
titl_plc = (0.07, 1.04)
rtxt_plc = (0.00, 0.98)
lett_plc = (0.0, 1.02)

# subplot placements
rect_ul = 0.077, 0.543, 0.44, 0.4
rect_ll = 0.077, 0.12, 0.44, 0.4
rect_ur = 0.540, 0.543, 0.44, 0.4
rect_lr = 0.540, 0.12, 0.44, 0.4

ex = 0.025
xe = 0.015
sx = 0.015

## panel titles

t1a = ''
t1b = ''
t1c = ''
t1d = ''

################ A
axa = fig.add_axes(rect_ul)

fylim1 = 4
fylim2 = 40.0

line1 = mcp.dateplt_m(tax1, zao11mn * 100, yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)), fylim=(-1 * fylim1, fylim1),
                      nomth=True, label='halosteric SSH (cm)', fmt='-')
line2 = mcp.dateplt_m(tax1, zao2_11mn * 100, yl=100, fxlim=(850, 1850), fylim=(-1 * fylim1, fylim1), nomth=True,
                      label='total SSH (cm)', fmt='-')
line3 = mcp.dateplt_m(tax1, fw1_11, color='red', yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)),
                      fylim=(-1 * fylim1, fylim1), nomth=True, label='freshwater (m)', fmt='-')

xlist = tax1[95::100]

axa.set_xticklabels('')
axa.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axa.set_xticks(xlist)

# ylabel('cm',size=10,va='center')

plt.title('Forced-run, 11-yr running means', size=9)

plt.legend(loc=2, prop=prop1)

z1a = zos_dt[:, j1, i1]
z2a = zos2_dt[:, j1, i1]
z1a_11 = mcmath.rm_calc(z1a, 'h', 11, 1)[1] * 100
z2a_11 = mcmath.rm_calc(z2a, 'h', 11, 1)[1] * 100
z2a_11 = z2a_11 - z2a_11.mean()

################ B
axb = fig.add_axes(rect_ll)
line1 = mcp.dateplt_m(tax1, z1a_11, yl=100, fylim=(-1 * fylim2, fylim2), nomth=True, label='$\dagger$ halosteric (cm)',
                      fmt='-')
line2 = mcp.dateplt_m(tax1, z2a_11, yl=100, fylim=(-1 * fylim2, fylim2), nomth=True, label='$\dagger$ total (cm)',
                      fmt='-')
line3 = mcp.dateplt_m(tax1, fwht1spot_11, color='red', yl=100, fylim=(-1 * fylim2, fylim2), nomth=True,
                      label='$\dagger$ freshwater (m)', fmt='-')

plt.legend(loc=2, prop=prop1)
axb.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axb.set_xticks(xlist)
# ylabel('SSH, cm',size=10,va='top')

################ C
axc = fig.add_axes(rect_ur)

line1 = mcp.dateplt_m(tax1, zao311mn[:990] * 100, yl=100, nomth=True, label='halosteric SSH (cm)', fmt='-')
line2 = mcp.dateplt_m(tax1, zao4_11mn[:990] * 100, yl=100, nomth=True, label='total SSH (cm)', fmt='-')
line3 = mcp.dateplt_m(tax1, fw2_11, color='red', yl=100, fxlim=(dt(850, 1, 1), dt(1850, 1, 1)),
                      fylim=(-1 * fylim1, fylim1), nomth=True, label='freshwater (m)', fmt='-')

axc.set_xticks(xlist)

axc.set_xticklabels('')
axc.set_yticklabels('')

plt.legend(loc=2, prop=prop1)
# ylabel('SSH mean, cm',size=10,va='center')

plt.title('Control-P, 11-yr running means', size=9)
axc.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))

z3a = zos3_dt[:, j1, i1]
z4a = zos4_dt[:, j1, i1]
z3a_11 = mcmath.rm_calc(z3a, 'h', 11, 1)[1] * 100
z4a_11 = mcmath.rm_calc(z4a, 'h', 11, 1)[1] * 100
z4a_11 = z4a_11 - z4a_11.mean()

################ D
axd = fig.add_axes(rect_lr)
line1 = mcp.dateplt_m(tax1, z3a_11[:990], yl=100, nomth=True, label='$\dagger$ halosteric (cm)', fmt='-')
line2 = mcp.dateplt_m(tax1, z4a_11[:990], yl=100, nomth=True, label='$\dagger$ total (cm)', fmt='-')
line3 = mcp.dateplt_m(tax1, fwht2spot_11, color='red', yl=100, fylim=(-1 * fylim2, fylim2), nomth=True,
                      label='$\dagger$ freshwater (m)', fmt='-')

axd.set_xticks(xlist)

axd.set_yticklabels('')

plt.legend(loc=2, prop=prop1)
axd.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))

plt.savefig('fig4_hster-mn-ssh-ctl-cmp-4c.png', dpi=300)
