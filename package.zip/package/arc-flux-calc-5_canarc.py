##  the freshwater flux estimate, plus sea ice transport estimate
##  positive flux into arctic region means positive freshwater flux
##  negative flux into arctic region means positive salt flux

from ferr import use
import netCDF4 as nc4
import numpy as np
import sys
import collections

d2 = use('basin_fx_MPI-ESM-P_past1000_r0i0p0.nc')
bas = d2.gv('basin')
latv2 = d2.v['lat_vertices'][:]
lonv2 = d2.v['lon_vertices'][:]
lat2 = d2.v['lat'][:]
lon2 = d2.v['lon'][:]

basshp = np.array(bas[:100].shape)
basshp[0] = basshp[0] - 1
basshp[1] = basshp[1] - 1
bas1 = bas[:100]

output = collections.OrderedDict()

## Bering Strait
output[(84, 7)] = 5

## Canadian Archipelago
output[(37, 27)] = 3  # 22
output[(37, 28)] = 3  # 23
output[(37, 29)] = 3  # 24

## Robeson Channel
output[(32, 2)] = 1  # 21

dg = use('GR15L40_fx.nc')
a2 = dg.gv('area')

dlxu = dg.gv('dlxu')
dlxv = dg.gv('dlxv')
dlxp = dg.gv('dlxp')

dlyu = dg.gv('dlyu')
dlyv = dg.gv('dlyv')
dlyp = dg.gv('dlyp')

deute = dg.gv('deute')  # depth_at_u_vector_point
deuto = dg.gv('deuto')  # depth_at_v_vector_point
ddue = dg.gv('ddue')  # ocean_level_thickness_at_v_vector_point
dduo = dg.gv('dduo')  # ocean_level_thickness_at_u_vector_point

dvo = nc4.MFDataset('vo/vo_ann_MPI-ESM-P_past1000*.nc')

latvo = dvo.variables['lat'][:]
lonvo = dvo.variables['lon'][:]

tax = dvo.variables['time'][:]
taxbnds = dvo.variables['time_bnds'][:]

zvo = dvo.variables['lev'][:]
zbndsvo = dvo.variables['lev_bnds'][:]

vo = dvo.variables['vo']

duo = nc4.MFDataset('uo/uo_ann_MPI-ESM-P_past1000*.nc')

latuo = duo.variables['lat'][:]
lonuo = duo.variables['lon'][:]
zuo = duo.variables['lev'][:]
zbndsuo = duo.variables['lev_bnds'][:]

uo = duo.variables['uo']

dso = nc4.MFDataset('so/so_ann_MPI-ESM-P_past1000*.nc')

latso = dso.variables['lat'][:]
lonso = dso.variables['lon'][:]
zso = dso.variables['lev'][:]
zbndsso = dso.variables['lev_bnds'][:]

so = dso.variables['so']

dtix = nc4.MFDataset('transi/transix_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')
dtiy = nc4.MFDataset('transi/transiy_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')

tix = dtix.variables['transix']
tiy = dtiy.variables['transiy']

zlen = zvo.size

tlen = uo.shape[0]

iall = output.keys()
ix = np.array(iall)

outlen = len(iall)
fwflux = np.ma.masked_all((outlen, tlen, zlen, 3), dtype=np.float32)
volflux = np.ma.masked_all((outlen, tlen, zlen, 3), dtype=np.float32)
iceflux = np.ma.masked_all((outlen, tlen, 3), dtype=np.float32)
lats = np.zeros((outlen,), dtype=np.float64)
lons = np.zeros((outlen,), dtype=np.float64)

i = 0

print "\nData gathered; files opened.  Ready to start main loop\n"
sys.stdout.flush()

f1 = open('arcflux5b.log', 'a+')

for key in iall:
    print "\nk: %d,%d\n" % (key[0], key[1])
    k1 = tuple(key)
    loc1 = output[k1]
    print 'loc = %d\n' % loc1
    sys.stdout.flush()

    ###  western face, flux of u0 to the 'west'
    ##  part of boxes labeled '1'
    if loc1 == 1:
        uo1 = uo[:, :, key[0], key[1] - 1]
        sograd = (so[:, :, key[0], key[1] - 1] + so[:, :, key[0], key[1]]) / 2.0
        fwf = (35.0 - sograd) / 35.  # fresh water fraction

        # dist01_ll = np.sqrt(Dlat01m**2 + Dlon01csm**2)
        dist01_xy = dlyu[key[0], key[1] - 1]

        fstr = 'i: %d :: key: %d, %d :: sograd: %.3f :: fwf: %.3f :: dist: %.3f\n' % (
            i, key[0], key[1], sograd[4, 2], fwf[4, 2], dist01_xy)
        f1.write(fstr)
        f1.flush()

        numlev = uo1[0].count()
        z3 = dduo[:, key[0], key[1] - 1]
        for lev in xrange(numlev):
            volflux[i, :, lev, 0] = dist01_xy * z3[lev] * -1. * uo1[:, lev]
            fwflux[i, :, lev, 0] = dist01_xy * z3[lev] * -1. * uo1[:, lev] * fwf[:, lev]
        icet = -1 * tix[:, key[0], key[1] - 1]
        if not np.ma.is_masked(icet):
            iceflux[i, :, 0] = icet

    ###  southern face, flux of v0 to the 'south'
    if loc1 == 3:
        vo1 = vo[:, :, key[0], key[1]]
        sograd = (so[:, :, key[0] + 1, key[1]] + so[:, :, key[0], key[1]]) / 2.0
        fwf = (35.0 - sograd) / 35.  # fresh water fraction

        dist12_xy = dlxv[key[0], key[1]]

        fstr = 'i: %d :: key: %d, %d :: sograd: %.3f :: fwf: %.3f :: dist: %.3f\n' % (
            i, key[0], key[1], sograd[4, 2], fwf[4, 2], dist12_xy)
        f1.write(fstr)
        f1.flush()

        numlev = vo1[0].count()
        z3 = ddue[:, key[0], key[1]]
        for lev in xrange(numlev):
            volflux[i, :, lev, 1] = dist12_xy * z3[lev] * -1.0 * vo1[:, lev]
            fwflux[i, :, lev, 1] = dist12_xy * z3[lev] * -1.0 * vo1[:, lev] * fwf[:, lev]

        icet = -1 * tiy[:, key[0], key[1]]
        if not np.ma.is_masked(icet):
            iceflux[i, :, 1] = icet

    ###  northern face, flux of v0 to the 'north'
    if loc1 == 5:
        vo1 = vo[:, :, key[0], key[1]]
        sograd = (so[:, :, key[0] + 1, key[1]] + so[:, :, key[0], key[1]]) / 2.0
        fwf = (35.0 - sograd) / 35.  # fresh water fraction

        dist12_xy = dlxv[key[0], key[1]]

        fstr = 'i: %d :: key: %d, %d :: sograd: %.3f :: fwf: %.3f :: dist: %.3f\n' % (
            i, key[0], key[1], sograd[4, 2], fwf[4, 2], dist12_xy)
        f1.write(fstr)
        f1.flush()

        numlev = vo1[0].count()
        z3 = ddue[:, key[0], key[1]]
        for lev in xrange(numlev):
            volflux[i, :, lev, 1] = dist12_xy * z3[lev] * vo1[:, lev]
            fwflux[i, :, lev, 1] = dist12_xy * z3[lev] * vo1[:, lev] * fwf[:, lev]

        icet = tiy[:, key[0], key[1]]
        if not np.ma.is_masked(icet):
            iceflux[i, :, 1] = icet

    i = i + 1

type1 = 'so'
v1_cellmeth = dso.variables[type1].cell_methods
v1_cellmeas = dso.variables[type1].cell_measures

lons = lon2[ix[:, 0], ix[:, 1]]
lats = lat2[ix[:, 0], ix[:, 1]]

nfname = 'fwflux_arc_5_canarc.nc'

dcur1 = nc4.Dataset(nfname, 'w', clobber=True, format='NETCDF3_CLASSIC')
dcur1.createDimension('ix', outlen)
dcur1.createDimension('time', 1000)
dcur1.createDimension('lev', 40)
dcur1.createDimension('ik', 3)
dcur1.createDimension('bnds', 2)

dcur1.history = 'created by script: %s' % 'arc-flux-calc-5_canarc.py'

time_var = dcur1.createVariable('time', 'd', ('time',))
time_var.long_name = 'time'
time_var.standard_name = 'time'
time_var.units = 'days since 0001-01-01 00:00:00'
time_var.bounds = 'time_bnds'
time_var.calendar = 'proleptic_gregorian'
time_var.axis = 'T'
time_var[:] = tax

timebnd_var = dcur1.createVariable('time_bnds', 'd', ('time', 'bnds'))
timebnd_var[:] = taxbnds

lat_var = dcur1.createVariable('lats', 'd', ('ix',))
lat_var.standard_name = 'latitude'
lat_var.long_name = "latitude coordinate"
lat_var.units = 'degrees_north'
lat_var.axis = 'Y'
lat_var[:] = lats

lon_var = dcur1.createVariable('lons', 'd', ('ix',))
lon_var.standard_name = 'longitude'
lon_var.long_name = "longitude coordinate"
lon_var.units = 'degrees_east'
lon_var.axis = 'X'
lon_var[:] = lons

lev_var = dcur1.createVariable('lev', 'd', ('lev',))
lev_var.long_name = 'ocean depth coordinate'
lev_var.standard_name = 'depth'
lev_var.units = 'm'
lev_var.bounds = 'lev_bnds'
lev_var.positive = 'down'
lev_var.axis = 'Z'
lev_var[:] = zvo

levbnd_var = dcur1.createVariable('lev_bnds', 'd', ('lev', 'bnds'))
levbnd_var[:] = zbndsvo

var1_var = dcur1.createVariable('fwflux', 'f', ('ix', 'time', 'lev', 'ik'), fill_value=-1e34)
var1_var.long_name = 'fresh water flux'
var1_var.standard_name = 'fwflux'
var1_var.units = 'm3 s-1'
var1_var.cell_methods = v1_cellmeth
var1_var.cell_measures = v1_cellmeas
var1_var.missing_value = np.float32(-1e34)

fwflux.data[fwflux.mask] = -1e34
var1_var[:] = fwflux[:].copy()

var2_var = dcur1.createVariable('iceflux', 'f', ('ix', 'time', 'ik'), fill_value=-1e34)
var2_var.long_name = 'sea ice mass flux'
var2_var.standard_name = 'iceflux'
var2_var.units = 'kg s-1'
var2_var.cell_methods = v1_cellmeth
var2_var.cell_measures = v1_cellmeas
var2_var.missing_value = np.float32(-1e34)

iceflux.data[iceflux.mask] = -1e34
var2_var[:] = iceflux[:].copy()

var3_var = dcur1.createVariable('volflux', 'f', ('ix', 'time', 'lev', 'ik'), fill_value=-1e34)
var3_var.long_name = 'volume flux'
var3_var.standard_name = 'volflux'
var3_var.units = 'm3 s-1'
var3_var.cell_methods = v1_cellmeth
var3_var.cell_measures = v1_cellmeas
var3_var.missing_value = np.float32(-1e34)

volflux.data[volflux.mask] = np.float32(-1e34)
var3_var[:] = volflux[:].copy()

dcur1.sync()
dcur1.close()
