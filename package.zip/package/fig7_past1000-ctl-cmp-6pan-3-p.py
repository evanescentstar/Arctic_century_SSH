import mcmath
from ferr import use
import netCDF4 as nc4
import numpy as np
import scipy as sp
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib import font_manager

prop1 = font_manager.FontProperties(size=8)

dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[:85]
area1 = area[:85]
ao_area = ao_msk1 * area1

### load P ctl pr
dpr_ctl = nc4.MFDataset('control/pr/pr_ann_MPI-ESM-*.nc')
pr_ctl = dpr_ctl.variables['pr'][:]
taxp = dpr_ctl.variables['time'][:]
darea_a = use('areacella_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area_a = darea_a.gv('areacella')
lata = darea_a.d['lat'][:]
lona = darea_a.d['lon'][:]

arcind = 80
ao_area_a = area_a[arcind:]
pr_ctlarc = (pr_ctl[:, arcind:] / 1000) * 86400 * 365

x1 = dpr_ctl.variables['lon'][:]
y1 = dpr_ctl.variables['lat'][arcind:]
tax_ctlp = dpr_ctl.variables['time'][:]

pr_ctl_dt = mcmath.my_dtrnd(pr_ctlarc, tax_ctlp, 0)
pr_ctl_dt_mn = mcmath.area_cswt_mean(pr_ctl_dt, y1)

pr_ctl_cum = pr_ctl_dt_mn.cumsum()
pr_ctl_cum_cm = pr_ctl_cum * 100

### load past1000 pr
dpr = use('pr/pr_ann_MPI-ESM-P_past1000_r1i1p1_085001-184912.nc')
pr = dpr.gv('pr')
prarc = (pr[:, arcind:] / 1000) * 86400 * 365
pr_dt = mcmath.my_dtrnd(prarc, np.arange(1000.), 0)
pr_dt_mn = mcmath.area_cswt_mean(pr_dt, y1)
pr_cum = pr_dt_mn.cumsum()
pr_cum_cm = pr_cum * 100

### load past1000 sic
dsic = nc4.MFDataset('ice/sic_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')
sic = dsic.variables['sic'][:]
tax = dsic.variables['time'][:]
sicarc = sic[:, :85] * ao_area
sicarcmn = sicarc.sum(axis=1).sum(axis=1) / ao_area.sum()

lonv1 = dsic.variables['lon_vertices'][:]
latv1 = dsic.variables['lat_vertices'][:]

sicdt = mcmath.my_dtrnd(sicarcmn, tax)
sic111 = mcmath.run_mean_win_mskd(sicdt, sp.signal.boxcar(111))[1]

t99 = np.arange(tax.size - 110)
t1000 = np.arange(tax.size)

### load P ctl sic
dsic_ctl = nc4.MFDataset('control/ice/sic_ann_MPI-ESM-P*.nc')
sic_ctl = dsic_ctl.variables['sic'][:]
tax_ctl = dsic_ctl.variables['time'][:]
sic_ctl_arc = sic_ctl[:, :85] * ao_area
sic_ctl_arcmn = sic_ctl_arc.sum(axis=1).sum(axis=1) / ao_area.sum()

sic_ctl_dt = mcmath.my_dtrnd(sic_ctl_arcmn, tax_ctl)
sic_ctl_111 = mcmath.run_mean_win_mskd(sic_ctl_dt, sp.signal.boxcar(111))[1]

### load P ctl wfo
dwfo_ctl = nc4.MFDataset('control/wfo/wfo_ann_*.nc')
wfo_ctl = dwfo_ctl.variables['wfo'][:, :85]
wfo_ctl_arc = wfo_ctl * 0.001 * ao_area.reshape(1, 85, 256)
wfof_ctl = (wfo_ctl_arc.sum(axis=1).sum(axis=1) / ao_area.sum()) * 365 * 86400 * 100
wfo_ctl_dt = mcmath.my_dtrnd(wfof_ctl, taxp, 0)
wfo_ctl_cum = (wfo_ctl_dt - wfo_ctl_dt.mean()).cumsum()

### load past1000 wfo
dwfo = nc4.MFDataset('wfo/wfo_ann_*.nc')
wfo = dwfo.variables['wfo'][:, :85]
wfoarc = wfo * 0.001 * ao_area.reshape(1, 85, 256)
wfof = (wfoarc.sum(axis=1).sum(axis=1) / ao_area.sum()) * 365 * 86400 * 100
wfodt = mcmath.my_dtrnd(wfof, tax, 0)
wfof111 = mcmath.run_mean_win_mskd(wfodt, sp.signal.boxcar(111))[1]
wfocum = (wfodt - wfodt.mean()).cumsum()

####
### transi ice transport past1000
####

dflux1 = nc4.Dataset('fwflux_arc_5_svalbard.nc')
zax = dflux1.variables['lev'][:]
lons1 = dflux1.variables['lons'][:]
lats1 = dflux1.variables['lats'][:]
iceflux1 = dflux1.variables['iceflux'][:] * (30. / 35.)

dflux2 = nc4.Dataset('fwflux_arc_5_canarc.nc')
lons2 = dflux2.variables['lons'][:]
lats2 = dflux2.variables['lats'][:]
iceflux2 = dflux2.variables['iceflux'][:] * (30. / 35.)

its1 = iceflux1.sum(axis=0).sum(axis=1) / 1000.
its2 = iceflux2.sum(axis=0).sum(axis=1) / 1000.

icedt1 = mcmath.my_dtrnd(its1, tax, 0)
icedt2 = mcmath.my_dtrnd(its2, tax, 0)

iceflux = np.r_[iceflux1, iceflux2] / 1000
icemask = np.r_[iceflux1.mask, iceflux2.mask]
iceflux.mask = icemask
icef_sum = iceflux.sum(axis=2).sum(axis=0)
icedt = mcmath.my_dtrnd(icef_sum, tax, 0)

icedt_m3 = icedt * 86400 * 365
icedt_cm = (icedt_m3 / ao_area.sum()) * 100

ice1 = icedt_cm[1:]
icecum_cm = ice1.cumsum()

#### end loading transi past1000

####
### transi ice transport ctl P
####

dflux1_ctl = nc4.Dataset('control/fwflux_arc_5_svalbard-P.nc')
zax_ctl = dflux1_ctl.variables['lev'][:]
lons1_ctl = dflux1_ctl.variables['lons'][:]
lats1_ctl = dflux1_ctl.variables['lats'][:]
iceflux1_ctl = dflux1_ctl.variables['iceflux'][:] * (30. / 35.)

dflux2_ctl = nc4.Dataset('control/fwflux_arc_5_canarc-P.nc')
lons2_ctl = dflux2_ctl.variables['lons'][:]
lats2_ctl = dflux2_ctl.variables['lats'][:]
iceflux2_ctl = dflux2_ctl.variables['iceflux'][:] * (30. / 35.)

its1_ctl = iceflux1_ctl.sum(axis=0).sum(axis=1) / 1000.
its2_ctl = iceflux2_ctl.sum(axis=0).sum(axis=1) / 1000.

icedt1_ctl = mcmath.my_dtrnd(its1_ctl, taxp, 0)
icedt2_ctl = mcmath.my_dtrnd(its2_ctl, taxp, 0)

iceflux_ctl = np.r_[iceflux2_ctl, iceflux1_ctl] / 1000
icemask_ctl = np.r_[iceflux2_ctl.mask, iceflux1_ctl.mask]
iceflux_ctl.mask = icemask_ctl
icef_sum_ctl = iceflux_ctl.sum(axis=2).sum(axis=0)
icedt_ctl = mcmath.my_dtrnd(icef_sum_ctl, taxp, 0)

icedt_ctl_m3 = icedt_ctl * 86400 * 365
icedt_ctl_cm = (icedt_ctl_m3 / ao_area.sum()) * 100

ice1_ctl = icedt_ctl_cm[1:]
icecum_ctl_cm = ice1_ctl.cumsum()

#### end loading transi ctl P


### load past1000 hssh
dhssh = use('hsteric-ssh-zmn-3.nc')

zos = dhssh.v['ssh'][:, :85]
zos_dt = mcmath.my_dtrnd(zos, np.arange(tax.size))

zaomn = (zos * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()
zos_lf_11 = mcmath.rm_calc(zos_dt, 'h', 11, 1)[1]

zao11mn = (zos_lf_11 * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

### load ctl P hssh
dhssh_ctl = use('control/ctl-hsteric-ssh-zmn.nc')
tax_ctl = dhssh_ctl.dt_vals('ssh')

zos_ctl = dhssh_ctl.v['ssh'][:, :85]
zos_dt_ctl = mcmath.my_dtrnd(zos_ctl, np.arange(tax_ctl.size))

zaomn_ctl = (zos_ctl * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

zos_lf_11_ctl = mcmath.rm_calc(zos_dt_ctl, 'h', 11, 1)[1]

zao11mn_ctl = (zos_lf_11_ctl * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

### load past1000 fwts

fwflux1 = dflux1.variables['fwflux'][:]
fwflux2 = dflux2.variables['fwflux'][:]

fwts1 = fwflux1.sum(axis=0).sum(axis=1).sum(axis=1)
fwts2 = fwflux2.sum(axis=0).sum(axis=1).sum(axis=1)
fwts4 = fwts1 + fwts2

fw4voldt = mcmath.my_dtrnd(fwts4, tax, 0)
fw4cum = fw4voldt.cumsum()

fw4cum_m3 = fw4cum * 86400 * 365
fw4cum_cm = (fw4cum_m3 / ao_area.sum()) * 100
fw4cum_cm_dt = mcmath.my_dtrnd(fw4cum_cm, tax, 0)

### load ctl P fwts

fwflux1_ctl = dflux1_ctl.variables['fwflux'][:]
fwflux2_ctl = dflux2_ctl.variables['fwflux'][:]

fwts1_ctl = fwflux1_ctl.sum(axis=0).sum(axis=1).sum(axis=1)
fwts2_ctl = fwflux2_ctl.sum(axis=0).sum(axis=1).sum(axis=1)
fw1voldt_ctl = mcmath.my_dtrnd(fwts1_ctl, taxp, 0)
fw2voldt_ctl = mcmath.my_dtrnd(fwts2_ctl, taxp, 0)

fwts4_ctl = fwts1_ctl + fwts2_ctl
fw4voldt_ctl = mcmath.my_dtrnd(fwts4_ctl, taxp, 0)
fw4cum_ctl = fw4voldt_ctl.cumsum()
fw4cum_m3_ctl = fw4cum_ctl * 86400 * 365
fw4cum_cm_ctl = (fw4cum_m3_ctl / ao_area.sum()) * 100

fw4cum_cm_ctl_dt = mcmath.my_dtrnd(fw4cum_cm_ctl, taxp, 0)

############ PLOTTING


# fig = figure(figsize=(8,7))
fig = plt.figure(figsize=(6, 5.5))

# text placements
titl_plc = (0.05, 1.04)
rtxt_plc = (0.00, 0.98)
lett_plc = (-0.05, 1.04)

xwid = 0.425
yht = 0.26
xrt = 0.565
xlf = 0.075

# subplot placements
rect_ll = xlf, 0.04, xwid, yht
rect_lr = xrt, 0.04, xwid, yht
rect_ml = xlf, 0.37, xwid, yht
rect_mr = xrt, 0.37, xwid, yht
rect_ul = xlf, 0.70, xwid, yht
rect_ur = xrt, 0.70, xwid, yht

t1a = 'FW changes: WFO - external fw (cm)'
t1b = 'FW changes: Ocean transport (cm)'
t1c = 'FW changes: Ice transport (cm)'
t1d = 'Total precipitation within 60$^{\circ}$N (cm)'
t1e = 'Sea ice cover fraction (%), Arc mean'
t1f = 'Halosteric SSH, Arc mean (cm)'

fylim1 = None
yl1 = 100
tcksz = 9
lettsz = 11
xadj = -0.02
titlsz = 9.5
fmt1 = '-'
fmt2 = 'r-'

t89 = np.arange(890.)
t99 = np.arange(990.)

################ A
ax_a = fig.add_axes(rect_ul)

p1 = mpl.mlab.detrend_linear(wfocum)
p2 = mpl.mlab.detrend_linear(wfo_ctl_cum)

t1 = t1000

l1 = 'p1000 (%.1f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.1f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax_a.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)
ax_a.axhline(0.0, color='k', lw=0.5)
ax_a.set_xticklabels('')
xtl = ax_a.get_xticklabels()
ytl = ax_a.get_yticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1a, ha='left', size=titlsz, transform=ax_a.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'a.)', ha='left', va='bottom', size=lettsz, transform=ax_a.transAxes)

###


################ B
ax = fig.add_axes(rect_ml)

p1 = fw4cum_cm_dt
p2 = fw4cum_cm_ctl_dt

t1 = t1000

l1 = 'p1000 (%.1f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.1f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)
ax.axhline(0.0, color='k', lw=0.5)
ax.set_xticklabels('')
xtl = ax.get_xticklabels()
ytl = ax.get_yticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz - 1)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1b, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'b.)', ha='left', va='bottom', size=lettsz, transform=ax.transAxes)

###


################ C
ax = fig.add_axes(rect_ll)

p1 = mpl.mlab.detrend_linear(icecum_cm)
p2 = mpl.mlab.detrend_linear(icecum_ctl_cm)

t1 = t1000[1:]

l1 = 'p1000 (%.1f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.1f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)
ax.axhline(0.0, color='k', lw=0.5)

ax.set_xticklabels('')
xtlab = np.array(['', '850', '1050', '1250', '1450', '1650', '1850', ''])
ax.set_xticklabels(xtlab)

ytl = ax.get_yticklabels()
xtl = ax.get_xticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1c, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'c.)', ha='left', va='bottom', size=lettsz, transform=ax.transAxes)

###


################ D
ax = fig.add_axes(rect_ur)

p1 = mpl.mlab.detrend_linear(pr_cum_cm)
p2 = mpl.mlab.detrend_linear(pr_ctl_cum_cm)

t1 = t1000

l1 = 'p1000 (%.1f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.1f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)
ax.axhline(0.0, color='k', lw=0.5)
ax.set_xticklabels('')
xtl = ax.get_xticklabels()
ytl = ax.get_yticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0], titl_plc[1], t1d, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'd.)', ha='left', va='bottom', size=lettsz, transform=ax.transAxes)

###


################ E
ax = fig.add_axes(rect_mr)

p1 = sic111
p2 = sic_ctl_111

t1 = t89

l1 = 'p1000 (%.2f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.2f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)

ax.set_xticklabels('')
xtl = ax.get_xticklabels()
ytl = ax.get_yticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0], titl_plc[1], t1e, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0], lett_plc[1], 'e.)', ha='left', va='bottom', size=lettsz, transform=ax.transAxes)

###

################ F
ax = fig.add_axes(rect_lr)

p1 = zao11mn * 100
p2 = zao11mn_ctl * 100

t1 = t99

l1 = 'p1000 (%.2f)' % p1.std(ddof=1)
l2 = 'ctl-p (%.2f)' % p2.std(ddof=1) + '\n ratio= %.2f' % (p1.std(ddof=1) / p2.std(ddof=1))

plt.plot(t1, p1, fmt1, label=l1)
ax.set_xticklabels('')
plt.plot(t1, p2[:-156], fmt2, label=l2)
ax.axhline(0.0, color='k', lw=0.5)

xtlab = np.array(['', '850', '1050', '1250', '1450', '1650', '1850', ''])
ax.set_xticklabels(xtlab)

xtl = ax.get_xticklabels()
ytl = ax.get_yticklabels()
plt.setp(xtl, 'size', tcksz)
plt.setp(ytl, 'size', tcksz)

plt.legend(loc=1, prop=prop1)

plt.text(titl_plc[0] + xadj, titl_plc[1], t1f, ha='left', size=titlsz, transform=ax.transAxes)
plt.text(lett_plc[0] + xadj, lett_plc[1], 'f.)', ha='left', va='bottom', size=lettsz, transform=ax.transAxes)

###

plt.savefig('fig7_past1000-ctl-cmp-6pan-3p.png', dpi=300)
