import mcmath
from ferr import use
import netCDF4 as nc4
import numpy as np
import scipy as sp
import mcp
from mcmath import d2n, n2d
from datetime import datetime as dt
from matplotlib import pyplot as plt
import matplotlib as mpl
from matplotlib import font_manager

prop1 = font_manager.FontProperties(size=9)

########################   AREAS AND ARCTIC MASKS
dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[:85]
area1 = area[:85]
ao_area = ao_msk1 * area1

darea.f.close()

#############


######################  Halosteric SSH
dhster = use('hsteric-ssh-zmn-3.nc')
lonv1 = dhster.v['lon_vertices'][:]
latv1 = dhster.v['lat_vertices'][:]

xax = lonv1
yax = latv1

dt1 = dhster.dt_vals('ssh')
tax = d2n(dt1)

hster = dhster.v['ssh'][:, :85]
hster_dt = mcmath.my_dtrnd(hster, np.arange(tax.size, dtype=np.float32), 0)

hstermn = (hster_dt * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()

hster_lf_11 = mcmath.rm_calc(hster_dt, 'b', 11, 1)[1]
hster_lf_111 = mcmath.rm_calc(hster_dt, 'b', 111, 1)[1]

hsternorm = hster_lf_11 / hster_lf_11.std(axis=0, ddof=1)

a1h = (hster_lf_11 * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()
a1hn = a1h / a1h.std(ddof=1)

a1h111 = (hster_lf_111 * ao_area.reshape(1, 85, 256)).sum(axis=1).sum(axis=1) / ao_area.sum()
a1hn111 = a1h111 / a1h111.std(ddof=1)
##########

################################### WFO (Water flux into ocean)
d1 = nc4.MFDataset('wfo/wfo_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')
t1 = d1.variables['time'][:]
dt1 = n2d(t1)

wfo = d1.variables['wfo'][:, :85]
wfoarc = wfo * 0.001 * ao_area.reshape(1, 85, 256)
wfof = wfoarc.sum(axis=1).sum(axis=1)
wfodt = mcmath.my_dtrnd(wfof, tax)
wfof11 = mcmath.run_mean_win_mskd(wfodt, sp.signal.boxcar(11))[1]

wfocum = (wfodt - wfodt.mean()).cumsum()
###############

############################  Freshwater flux through Arctic perimeter
dflux1 = nc4.Dataset('fwflux_arc_5_svalbard.nc')
zax = dflux1.variables['lev'][:]
lons1 = dflux1.variables['lons'][:]
lats1 = dflux1.variables['lats'][:]
fwflux1 = dflux1.variables['fwflux'][:]
iceflux1 = dflux1.variables['iceflux'][:] * (30. / 35.)
volflux1 = dflux1.variables['volflux'][:]

dflux2 = nc4.Dataset('fwflux_arc_5_canarc.nc')
lons2 = dflux2.variables['lons'][:]
lats2 = dflux2.variables['lats'][:]
fwflux2 = dflux2.variables['fwflux'][:]
iceflux2 = dflux2.variables['iceflux'][:] * (30. / 35.)
volflux2 = dflux2.variables['volflux'][:]

fwts1 = fwflux1.sum(axis=0).sum(axis=1).sum(axis=1)
fwts2 = fwflux2.sum(axis=0).sum(axis=1).sum(axis=1)

its1 = iceflux1.sum(axis=0).sum(axis=1) / 1000.
its2 = iceflux2.sum(axis=0).sum(axis=1) / 1000.

icedt1 = mcmath.my_dtrnd(its1, tax, 0)
icedt2 = mcmath.my_dtrnd(its2, tax, 0)

fwflux = np.r_[fwflux1, fwflux2]
fwmask = np.r_[fwflux1.mask, fwflux2.mask]
fwflux.mask = fwmask

fwf_sum = fwflux.sum(axis=3).sum(axis=0)

iceflux = np.r_[iceflux1, iceflux2] / 1000
icemask = np.r_[iceflux1.mask, iceflux2.mask]
iceflux.mask = icemask
icef_sum = iceflux.sum(axis=2).sum(axis=0)

fwts4 = fwts1 + fwts2

fw4voldt = mcmath.my_dtrnd(fwts4, tax, 0)
icedt = mcmath.my_dtrnd(icef_sum, tax, 0)

fw4cum = fw4voldt.cumsum()
icecum = icedt.cumsum()

fw4cum_m3 = fw4cum * 86400 * 365
fw4cum_cm = (fw4cum_m3 / ao_area.sum()) * 100

wfocum_m3 = wfocum * 86400 * 365
wfocum_cm = (wfocum_m3 / ao_area.sum()) * 100

icecum_m3 = icecum * 86400 * 365
icecum_cm = (icecum_m3 / ao_area.sum()) * 100
###################

#################   PLOTTING

netfw = fw4cum_cm + wfocum_cm + icecum_cm

dt1dt = mpl.dates.num2date(t1)
yllen = 200
plt.figure()
mcp.dateplt_m(dt1dt[5:-5], a1h * 3600, yl=yllen, fmt='-', ticksize=10, color='steelblue', lw=3,
              label='Halosteric SSH (scaled, x 36)')
mcp.dateplt_m(dt1dt, netfw - netfw.mean(), ticksize=10, yl=yllen, fmt='--', lw=1, color='black', label='Net FW')
mcp.dateplt_m(dt1dt, fw4cum_cm - fw4cum_cm.mean(), ticksize=10, yl=yllen, fmt='-', color='firebrick',
              label='Net Ocean FW transport')
mcp.dateplt_m(dt1dt, wfocum_cm - wfocum_cm.mean(), ticksize=10, yl=yllen, fmt='-', color='orange',
              label='WFO - external FW input')
mcp.dateplt_m(dt1dt, icecum_cm - icecum_cm.mean(), ticksize=10, yl=yllen, fmt='-', color='olive',
              label='Net ice transport')

plt.legend(loc=4, prop=prop1)
plt.xlabel('')

xlist = dt1dt[::100]
axa = plt.gca()
axa.set_xlim(dt(850, 1, 1), dt(1850, 1, 1))
axa.set_xticks(xlist)
plt.title('Arctic mean freshwater content changes, in cm')

plt.savefig('fig6_subcomp-hssh-cmp-4_cm.png',dpi=300)
##
