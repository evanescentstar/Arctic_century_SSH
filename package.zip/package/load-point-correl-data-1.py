import mcmath
from ferr import use
import netCDF4 as nc4
import numpy as np
import scipy as sp

########################   AREAS AND ARCTIC MASKS
dmsk = nc4.Dataset('arcmsk2.nc')
amsk = dmsk.variables['mask'][:]

darea = use('areacello_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area = darea.gv('areacello')
ao_msk1 = amsk[:85]
area1 = area[:85]
ao_area = ao_msk1 * area1

darea.f.close()

darea = use('areacella_fx_MPI-ESM-P_past1000_r0i0p0.nc')
area_a = darea.gv('areacella')
lata = darea.d['lat'][:]
lona = darea.d['lon'][:]

arcind = 80
ao_area_a = area_a[arcind:]
#############

d1 = use('tas/tas_ann_MPI-ESM-P_past1000_r1i1p1_085001-184912.nc')
tax = d1.d['time'][:]
tas = d1.gv('tas')
arc_tas_mn = mcmath.area_cswt_mean(tas[:, -5:], tas.y[-5:])
atm_dt = mcmath.my_dtrnd(arc_tas_mn, tas.t, 0)
atm_111 = mcmath.run_mean_win_mskd(atm_dt, sp.signal.boxcar(111))[1]
atm_nodtrnd111 = mcmath.run_mean_win_mskd(arc_tas_mn, sp.signal.boxcar(111))[1]
and111_cel = atm_nodtrnd111 - 273.15

a1norm = atm_111 - atm_111.mean()
a1norm = a1norm / a1norm.std()

########################   PSL
dpsl = use('psl/psl_ann_MPI-ESM-P_past1000_r1i1p1_085001-184912.nc')
psl = dpsl.gv('psl')

#############

d1 = nc4.MFDataset('wfo/wfo_ann_MPI-ESM-P_past1000_r1i1p1_*.nc')
t1 = d1.variables['time'][:]
dt1 = mcmath.n2d(t1)

wfo = d1.variables['wfo'][:, :85]
wfoarc = wfo * 0.001 * ao_area.reshape(1, 85, 256)
wfof = wfoarc.sum(axis=1).sum(axis=1)
wfodt = mcmath.my_dtrnd(wfof, tax)

dflux1 = nc4.Dataset('fwflux_arc_5_svalbard.nc')
zax = dflux1.variables['lev'][:]
lons1 = dflux1.variables['lons'][:]
lats1 = dflux1.variables['lats'][:]
iceflux1 = dflux1.variables['iceflux'][:] * (30. / 35.)

dflux2 = nc4.Dataset('fwflux_arc_5_canarc.nc')
lons2 = dflux2.variables['lons'][:]
lats2 = dflux2.variables['lats'][:]
iceflux2 = dflux2.variables['iceflux'][:] * (30. / 35.)


iceflux = np.r_[iceflux1, iceflux2] / 1000
icemask = np.r_[iceflux1.mask, iceflux2.mask]
iceflux.mask = icemask
icef_sum = iceflux.sum(axis=2).sum(axis=0)
icef_std = icef_sum.std(axis=0, ddof=1)
icef_sum111 = mcmath.rm_calc(icef_sum, npts=111)[1]
